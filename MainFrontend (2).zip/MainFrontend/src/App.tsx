import React from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { ChatHistoryProvider } from './contexts/ChatHistoryContext';
import { AnimatePresence } from 'framer-motion';
import ProtectedRoute from './components/ProtectedRoute';

import LandingPage from './components/LandingPage';
import LoginPage from './components/LoginPage';
import PredictionPage from './components/PredictionPage';
import SubscriptionPage from './components/SubscriptionPage';
import SubscriptionSuccessPage from './components/SubscriptionSuccessPage';
import Navbar from './components/Navbar';
import DeveloperAuth from './components/DeveloperAuth';
import ProfilePage from './components/ProfilePage';
import VisualizationPage from './components/VisualizationPage';

// Loading Spinner Component
export const LoadingSpinner = () => (
  <div className="min-h-screen bg-black flex items-center justify-center">
    <div className="text-center text-gray-300">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-500 mx-auto"></div>
      <p className="mt-4 font-display">INITIALIZING...</p>
    </div>
  </div>
);

// Main App Content
const AppContent = () => {
  const location = useLocation();

  return (
    <div className="min-h-screen bg-black">
      {location.pathname !== '/' && location.pathname !== '/login' && location.pathname !== '/signup' && location.pathname !== '/developer' && <Navbar />}
      <AnimatePresence mode="wait">
        <Routes location={location} key={location.pathname}>
          {/* Public routes */}
          <Route path="/" element={<LandingPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/signup" element={<LoginPage isSignUp={true} />} />
          <Route path="/developer" element={<DeveloperAuth />} />
          
          {/* Feature pages */}
          <Route path="/features" element={<LandingPage scrollTo="features" />} />
          <Route path="/solutions" element={<LandingPage scrollTo="solutions" />} />
          <Route path="/enterprise" element={<LandingPage scrollTo="enterprise" />} />
          <Route path="/pricing" element={<LandingPage scrollTo="pricing" />} />
          <Route path="/contact" element={<LandingPage scrollTo="contact" />} />

          {/* Protected routes - Developer users bypass subscription check */}
          <Route
            path="/prediction"
            element={
              <ProtectedRoute requiresSubscription={true}>
                <PredictionPage />
              </ProtectedRoute>
            }
          />

          {/* Protected routes - No subscription required */}
          <Route
            path="/subscription"
            element={
              <ProtectedRoute>
                <SubscriptionPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/subscription/success"
            element={
              <ProtectedRoute>
                <SubscriptionSuccessPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/profile"
            element={
              <ProtectedRoute>
                <ProfilePage />
              </ProtectedRoute>
            }
          />

          {/* Visualization routes - Protected and require subscription (bypassed for developers) */}
          <Route
            path="/visualization/:chartType"
            element={
              <ProtectedRoute requiresSubscription={true}>
                <VisualizationPage />
              </ProtectedRoute>
            }
          />

          {/* Catch-all route - redirect to landing page */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </AnimatePresence>
    </div>
  );
};

// Root App Component
const App = () => {
  return (
    <BrowserRouter>
      <AuthProvider>
        <ChatHistoryProvider>
          <AppContent />
        </ChatHistoryProvider>
      </AuthProvider>
    </BrowserRouter>
  );
};

export default App;
