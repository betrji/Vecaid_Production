import * as React from 'react';
import * as THREE from 'three';
import { OrbitControls as OrbitControlsImpl } from '@react-three/drei';

declare global {
  namespace JSX {
    interface IntrinsicElements {
      mesh: React.DetailedHTMLProps<React.HTMLAttributes<THREE.Mesh>, THREE.Mesh>;
      torusKnotGeometry: React.DetailedHTMLProps<React.HTMLAttributes<THREE.TorusKnotGeometry>, THREE.TorusKnotGeometry> & {
        args?: [number, number, number, number];
      };
      meshStandardMaterial: React.DetailedHTMLProps<React.HTMLAttributes<THREE.MeshStandardMaterial>, THREE.MeshStandardMaterial> & {
        color?: string | number;
        metalness?: number;
        roughness?: number;
      };
      ambientLight: React.DetailedHTMLProps<React.HTMLAttributes<THREE.AmbientLight>, THREE.AmbientLight> & {
        intensity?: number;
      };
      directionalLight: React.DetailedHTMLProps<React.HTMLAttributes<THREE.DirectionalLight>, THREE.DirectionalLight> & {
        position?: [number, number, number];
        intensity?: number;
      };
      orbitControls: React.DetailedHTMLProps<React.HTMLAttributes<OrbitControlsImpl>, OrbitControlsImpl> & {
        enableZoom?: boolean;
      };
    }
  }
} 