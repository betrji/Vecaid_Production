import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api/config';

interface DeveloperStatus {
  isActive: boolean;
  apiKey?: string;
  permissions: string[];
}

export const useDeveloper = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const authenticateWithKey = async (key: string): Promise<boolean> => {
    setLoading(true);
    setError(null);
    
    try {
      // Remove any existing token
      localStorage.removeItem('authToken');
      
      // Make the authentication request
      const response = await api.post('/api/auth/developer', { key });
      
      if (response.data.token) {
        // Store the token
        localStorage.setItem('authToken', response.data.token);
        
        // Navigate to prediction page
        navigate('/prediction', { replace: true });
        return true;
      }
      
      setError('Invalid response from server');
      return false;
    } catch (err: any) {
      console.error('Developer authentication error:', err);
      
      if (err.response?.status === 401) {
        setError('Invalid developer key');
      } else if (err.response?.status === 403) {
        setError('Access denied');
      } else if (err.code === 'ERR_NETWORK') {
        setError('Cannot connect to server. Please ensure the backend is running.');
      } else {
        setError(err.response?.data?.error || err.message || 'Failed to authenticate');
      }
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return {
    authenticateWithKey,
    loading,
    error
  };
};

export type { DeveloperStatus };

export default useDeveloper;
