import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import api from '../api/config';

interface SubscriptionStatus {
    isActive: boolean;
    plan: string | null;
    expiresAt: string | null;
    cancelAtPeriodEnd: boolean;
}

interface CheckoutSession {
    url: string;
    sessionId: string;
}

interface SubscriptionError {
    message: string;
    code?: string;
}

export const useSubscription = () => {
    const { isAuthenticated } = useAuth();
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<SubscriptionError | null>(null);

    const createCheckoutSession = async () => {
        if (!isAuthenticated) {
            setError({ message: 'Authentication required', code: 'AUTH_REQUIRED' });
            return;
        }

        setLoading(true);
        setError(null);

        try {
            const response = await api.post('/api/subscription/create-checkout');
            window.location.href = response.data.url;
        } catch (err: any) {
            setError({
                message: err.response?.data?.error || 'Failed to create checkout session',
                code: err.response?.data?.code || 'CHECKOUT_ERROR'
            });
            throw err;
        } finally {
            setLoading(false);
        }
    };

    const checkSubscriptionStatus = async () => {
        if (!isAuthenticated) {
            setError({ message: 'Authentication required', code: 'AUTH_REQUIRED' });
            return null;
        }

        setLoading(true);
        setError(null);

        try {
            const response = await api.get('/api/subscription/status');
            return response.data;
        } catch (err: any) {
            setError({
                message: err.response?.data?.error || 'Failed to check subscription status',
                code: err.response?.data?.code || 'STATUS_ERROR'
            });
            return null;
        } finally {
            setLoading(false);
        }
    };

    const cancelSubscription = async (): Promise<void> => {
        if (!isAuthenticated) {
            throw new Error('Authentication required');
        }

        setLoading(true);
        setError(null);

        try {
            await api.post('/api/subscription/cancel');
        } catch (err: any) {
            const subscriptionError = {
                message: err.response?.data?.error || err.message || 'Failed to cancel subscription',
                code: err.response?.status?.toString()
            };
            setError(subscriptionError);
            throw subscriptionError;
        } finally {
            setLoading(false);
        }
    };

    const updatePaymentMethod = async (): Promise<CheckoutSession> => {
        if (!isAuthenticated) {
            throw new Error('Authentication required');
        }

        setLoading(true);
        setError(null);

        try {
            const response = await api.post<CheckoutSession>('/api/subscription/update-payment');
            return response.data;
        } catch (err: any) {
            const subscriptionError = {
                message: err.response?.data?.error || err.message || 'Failed to update payment method',
                code: err.response?.status?.toString()
            };
            setError(subscriptionError);
            throw subscriptionError;
        } finally {
            setLoading(false);
        }
    };

    const clearError = () => {
        setError(null);
    };

    return {
        createCheckoutSession,
        checkSubscriptionStatus,
        clearError,
        loading,
        error,
        cancelSubscription,
        updatePaymentMethod
    };
};

// Export types for use in components
export type { SubscriptionStatus, CheckoutSession, SubscriptionError }; 