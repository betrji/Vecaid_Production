import { useState, useEffect, useCallback } from 'react';
import api from '../api/config';

interface User {
  email: string;
  isSubscribed: boolean;
  isDeveloper: boolean;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  signup: (email: string, password: string) => Promise<void>;
  logout: () => void;
  handleSubscribe: () => Promise<void>;
  checkAuth: () => Promise<void>;
}

export const useAuth = (): AuthContextType => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const checkAuth = useCallback(async () => {
    try {
      const token = localStorage.getItem('authToken');
      if (!token) {
        setUser(null);
        setIsLoading(false);
        return;
      }

      const response = await api.get('/api/auth/check');
      if (response.data.user) {
        setUser(response.data.user);
      } else {
        setUser(null);
        localStorage.removeItem('authToken');
      }
    } catch (err) {
      console.error('Auth check error:', err);
      setUser(null);
      localStorage.removeItem('authToken');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    checkAuth();
  }, [checkAuth]);

  const login = async (email: string, password: string) => {
    try {
      setError(null);
      const response = await api.post('/api/auth/login', { email, password });
      const { token, user } = response.data;
      localStorage.setItem('authToken', token);
      setUser(user);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Login failed');
      throw err;
    }
  };

  const signup = async (email: string, password: string) => {
    try {
      setError(null);
      const response = await api.post('/api/auth/signup', { email, password });
      const { token } = response.data;
      localStorage.setItem('authToken', token);
      await checkAuth();
    } catch (err: any) {
      setError(err.response?.data?.error || 'Signup failed');
      throw err;
    }
  };

  const logout = () => {
    localStorage.removeItem('authToken');
    setUser(null);
  };

  const handleSubscribe = async () => {
    try {
      setError(null);
      const response = await api.post('/api/subscription/create-checkout');
      if (response.data.url) {
        window.location.href = response.data.url;
      } else {
        throw new Error('No checkout URL received');
      }
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to start subscription process');
      throw err;
    }
  };

  return {
    user,
    isAuthenticated: !!user,
    isLoading,
    error,
    login,
    signup,
    logout,
    handleSubscribe,
    checkAuth
  };
};

export default useAuth; 