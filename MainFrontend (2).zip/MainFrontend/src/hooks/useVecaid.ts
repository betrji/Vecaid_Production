import { useState, useCallback, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { api, endpoints } from '../api/config';
import { useWebSocket } from './useWebSocket';

interface TechnicalIndicators {
  rsi: number;
  macd: number;
  signal: number;
  bollinger_bands: {
    upper: number;
    middle: number;
    lower: number;
  };
}

interface PredictionData {
  ticker: string;
  training_info?: {
    training_time: number;
    final_loss: number;
  };
  ml_prediction?: {
    direction: 'up' | 'down';
    confidence: number;
    target_price: number;
    predicted_move: number;
    predicted_date: string;
  };
  backtest_results?: {
    statistics: {
      accuracy_percentage: number;
      mean_absolute_error: number;
      rmse_price: number;
    };
    predictions: number[];
    actuals: number[];
  };
  technical_indicators?: TechnicalIndicators;
  visualization?: string;
  status: 'idle' | 'loading' | 'success' | 'error';
  error?: string;
  progress?: number;
  step?: string;
}

interface PredictionResponse {
  ticker: string;
  training_info: {
    training_time: number;
    final_loss: number;
  };
  ml_prediction: {
    direction: 'up' | 'down';
    confidence: number;
    target_price: number;
    predicted_move: number;
    predicted_date: string;
  };
  backtest_results: {
    statistics: {
      accuracy_percentage: number;
      mean_absolute_error: number;
      rmse_price: number;
    };
    predictions: number[];
    actuals: number[];
  };
  technical_indicators: TechnicalIndicators;
  visualization: string;
}

export const useVecaid = () => {
  const { user } = useAuth();
  const [predictions, setPredictions] = useState<Record<string, PredictionData>>({});
  const [isProcessing, setIsProcessing] = useState(false);
  const [hasFirstPrediction, setHasFirstPrediction] = useState(false);
  const [currentTicker, setCurrentTicker] = useState<string | null>(null);

  const handlePredictionStatus = useCallback((data: any) => {
    if (!currentTicker) return;
    setPredictions(prev => ({
      ...prev,
      [currentTicker]: {
        ...prev[currentTicker],
        status: 'loading',
        progress: data.progress,
        step: data.step
      }
    }));
  }, [currentTicker]);

  const handlePredictionComplete = useCallback((data: PredictionResponse) => {
    if (!currentTicker) return;
    setPredictions(prev => ({
      ...prev,
      [currentTicker]: {
        ...data,
        status: 'success'
      }
    }));
    setIsProcessing(false);
  }, [currentTicker]);

  const handlePredictionError = useCallback((error: any) => {
    if (!currentTicker) return;
    setPredictions(prev => ({
      ...prev,
      [currentTicker]: {
        ticker: currentTicker,
        status: 'error',
        error: error.message || 'An error occurred during prediction'
      }
    }));
    setIsProcessing(false);
  }, [currentTicker]);

  const { socket } = useWebSocket(currentTicker || '', {
    onPredictionStatus: handlePredictionStatus,
    onPredictionComplete: handlePredictionComplete,
    onPredictionError: handlePredictionError
  });

  // Clear predictions when auth state changes
  useEffect(() => {
    if (!user) {
      setPredictions({});
      setHasFirstPrediction(false);
      setCurrentTicker(null);
    }
  }, [user]);

  const makePrediction = useCallback(async (ticker: string) => {
    if (!user) {
      throw new Error('Authentication required');
    }

    try {
      setIsProcessing(true);
      setCurrentTicker(ticker);
      setPredictions(prev => ({
        ...prev,
        [ticker]: { ticker, status: 'loading', progress: 0 }
      }));

      const response = await api.post<{ message: string; websocket_channel: string }>(
        endpoints.predictions.info,
        { ticker }
      );
      
      if (!hasFirstPrediction && !user.isSubscribed && !user.directAccess) {
        setHasFirstPrediction(true);
      }

      return response.data;
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || 'Failed to make prediction';
      setPredictions(prev => ({
        ...prev,
        [ticker]: {
          ticker,
          status: 'error',
          error: errorMessage
        }
      }));
      setIsProcessing(false);
      throw new Error(errorMessage);
    }
  }, [user, hasFirstPrediction]);

  const cancelPrediction = useCallback(async (ticker: string) => {
    if (!user) {
      throw new Error('Authentication required');
    }

    try {
      await api.post(endpoints.predictions.cancel(ticker));
      setPredictions(prev => {
        const newPredictions = { ...prev };
        delete newPredictions[ticker];
        return newPredictions;
      });
      if (currentTicker === ticker) {
        setCurrentTicker(null);
      }
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || 'Failed to cancel prediction';
      console.error('Failed to cancel prediction:', errorMessage);
      throw new Error(errorMessage);
    }
  }, [user, currentTicker]);

  const clearPrediction = useCallback((ticker: string) => {
    setPredictions(prev => {
      const newPredictions = { ...prev };
      delete newPredictions[ticker];
      return newPredictions;
    });
    if (currentTicker === ticker) {
      setCurrentTicker(null);
    }
  }, [currentTicker]);

  return {
    predictions,
    isProcessing,
    hasFirstPrediction,
    currentTicker,
    makePrediction,
    cancelPrediction,
    clearPrediction
  };
};

// Export types for use in components
export type { PredictionData, PredictionResponse, TechnicalIndicators }; 