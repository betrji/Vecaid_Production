import { useEffect, useRef, useCallback } from 'react';
import { io, Socket } from 'socket.io-client';
import { getWebSocketUrl } from '../api/config';
import { PredictionResponse } from './useVecaid';

interface PredictionStatus {
  step: string;
  progress: number;
  message?: string;
}

interface PredictionError {
  message: string;
  code?: string;
}

interface WebSocketHookOptions {
  onConnect?: () => void;
  onDisconnect?: () => void;
  onPredictionStatus?: (data: PredictionStatus) => void;
  onPredictionComplete?: (data: PredictionResponse) => void;
  onPredictionError?: (error: PredictionError) => void;
}

export const useWebSocket = (ticker: string, options: WebSocketHookOptions = {}) => {
  const socketRef = useRef<Socket | null>(null);

  const connect = useCallback(() => {
    if (socketRef.current?.connected) return;

    const socket = io(getWebSocketUrl(), {
      transports: ['websocket'],
      autoConnect: true,
    });

    socket.on('connect', () => {
      console.log('WebSocket connected');
      socket.emit('subscribe', { ticker });
      options.onConnect?.();
    });

    socket.on('disconnect', () => {
      console.log('WebSocket disconnected');
      options.onDisconnect?.();
    });

    socket.on('prediction_status', (data: PredictionStatus) => {
      console.log('Prediction status update:', data);
      options.onPredictionStatus?.(data);
    });

    socket.on('prediction_complete', (data: PredictionResponse) => {
      console.log('Prediction complete:', data);
      options.onPredictionComplete?.(data);
    });

    socket.on('prediction_error', (error: PredictionError) => {
      console.error('Prediction error:', error);
      options.onPredictionError?.(error);
    });

    socketRef.current = socket;
  }, [ticker, options]);

  const disconnect = useCallback(() => {
    if (socketRef.current) {
      socketRef.current.disconnect();
      socketRef.current = null;
    }
  }, []);

  useEffect(() => {
    connect();
    return () => {
      disconnect();
    };
  }, [connect, disconnect]);

  return {
    socket: socketRef.current,
    connect,
    disconnect,
  };
}; 