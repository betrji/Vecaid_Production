import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useVecaid } from '../hooks/useVecaid';
import { useAuth } from '../contexts/AuthContext';

interface PredictionWrapperProps {
  children: React.ReactNode;
}

export const PredictionWrapper: React.FC<PredictionWrapperProps> = ({ children }) => {
  const { hasFirstPrediction } = useVecaid();
  const { isSubscribed } = useAuth();
  const navigate = useNavigate();

  // If user has made their first prediction and isn't subscribed, show subscription page
  React.useEffect(() => {
    if (hasFirstPrediction && !isSubscribed) {
      navigate('/subscription', { 
        state: { 
          fromPrediction: true,
          message: "Great! You've seen how VECAID works. Subscribe now to continue making predictions and unlock all features." 
        } 
      });
    }
  }, [hasFirstPrediction, isSubscribed, navigate]);

  return <>{children}</>;
};

export default PredictionWrapper; 