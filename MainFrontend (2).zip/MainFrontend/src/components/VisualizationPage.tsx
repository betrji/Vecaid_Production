import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FaArrowLeft } from 'react-icons/fa';

interface ChartData {
  title: string;
  description: string;
  imageUrl: string;
}

const VisualizationPage: React.FC = () => {
  const { chartType } = useParams<{ chartType: string }>();
  const navigate = useNavigate();

  const chartData: Record<string, ChartData> = {
    'prediction-vs-actual': {
      title: 'Prediction vs Actual',
      description: 'Compare our AI model\'s predictions against actual market performance. This visualization helps you understand the accuracy of our predictions over time.',
      imageUrl: '' // Will be populated dynamically
    },
    'cumulative-return': {
      title: 'Cumulative Return',
      description: 'Track the cumulative returns based on our predictions. This chart shows the potential growth of your investment if you followed our signals.',
      imageUrl: '' // Will be populated dynamically
    },
    'price-comparison': {
      title: 'Price Comparison',
      description: 'See how different price metrics compare over time. This visualization helps identify trends and patterns in price movements.',
      imageUrl: '' // Will be populated dynamically
    }
  };

  const currentChart = chartData[chartType || ''];

  if (!currentChart) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-white text-center">
          <h1 className="text-2xl font-display mb-4">Chart not found</h1>
          <button
            onClick={() => navigate('/prediction')}
            className="text-cyan-500 hover:text-cyan-400 transition-colors"
          >
            Return to Predictions
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 gradient-grid opacity-20" />
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/50 to-black" />

      {/* Main Content */}
      <div className="relative z-10 container mx-auto px-4 py-8">
        <motion.button
          onClick={() => navigate('/prediction')}
          className="flex items-center space-x-2 text-cyan-500 hover:text-cyan-400 transition-colors mb-8"
          whileHover={{ x: -4 }}
        >
          <FaArrowLeft />
          <span>Back to Predictions</span>
        </motion.button>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="bg-gray-900/50 border border-gray-800 rounded-2xl p-8"
        >
          <h1 className="text-3xl font-display text-white mb-4">{currentChart.title}</h1>
          <p className="text-gray-400 mb-8">{currentChart.description}</p>

          {/* Chart Container */}
          <div className="relative rounded-xl overflow-hidden border border-gray-800">
            {currentChart.imageUrl ? (
              <img
                src={currentChart.imageUrl}
                alt={currentChart.title}
                className="w-full h-auto"
              />
            ) : (
              <div className="aspect-video bg-gray-800/50 flex items-center justify-center">
                <p className="text-gray-500">Chart loading...</p>
              </div>
            )}
          </div>

          {/* Interactive Controls */}
          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
            <button className="p-4 bg-gray-800/50 rounded-xl border border-gray-700 hover:border-cyan-500/50 transition-colors">
              <h3 className="text-white font-display mb-2">Time Range</h3>
              <p className="text-gray-400 text-sm">Adjust the visualization period</p>
            </button>
            <button className="p-4 bg-gray-800/50 rounded-xl border border-gray-700 hover:border-cyan-500/50 transition-colors">
              <h3 className="text-white font-display mb-2">Indicators</h3>
              <p className="text-gray-400 text-sm">Toggle technical indicators</p>
            </button>
            <button className="p-4 bg-gray-800/50 rounded-xl border border-gray-700 hover:border-cyan-500/50 transition-colors">
              <h3 className="text-white font-display mb-2">Export</h3>
              <p className="text-gray-400 text-sm">Download chart data</p>
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default VisualizationPage; 