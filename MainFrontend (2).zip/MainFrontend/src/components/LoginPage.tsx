import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { motion, AnimatePresence } from 'framer-motion';

interface LoginPageProps {
  isSignUp?: boolean;
}

const LoginPage: React.FC<LoginPageProps> = ({ isSignUp = false }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login, signup, error, clearError, user } = useAuth();
  const navigate = useNavigate();

  // Redirect if already authenticated
  useEffect(() => {
    if (user) {
      if (user.directAccess) {
        // Developer with direct access goes straight to prediction
        navigate('/prediction', { replace: true });
      } else if (!user.isSubscribed) {
        // Non-subscribed users go to subscription page
        navigate('/subscription', { replace: true });
      } else {
        // Regular subscribed users go to prediction
        navigate('/prediction', { replace: true });
      }
    }
  }, [user, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    clearError();

    try {
      if (isSignUp) {
        await signup(email, password);
      } else {
        await login(email, password);
      }
    } catch (err) {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black relative overflow-hidden flex items-center justify-center p-4">
      {/* Background effects */}
      <div className="fixed inset-0 overflow-hidden">
        {[...Array(40)].map((_, i) => (
          <div
            key={i}
            className="absolute bg-gradient-to-r from-transparent via-purple-500/10 to-transparent"
            style={{
              width: '300%',
              height: '2px',
              left: '-100%',
              top: `${Math.random() * 100}%`,
              transform: 'rotate(35deg)',
              animation: `floatLine ${20 + Math.random() * 15}s linear infinite`,
              animationDelay: `${-Math.random() * 10}s`,
              opacity: 0.2
            }}
          />
        ))}
      </div>

      {/* Holographic scan lines */}
      <div className="fixed inset-0 pointer-events-none">
        {[...Array(50)].map((_, i) => (
          <div
            key={i}
            className="absolute w-full h-px bg-gradient-to-r from-transparent via-purple-400/5 to-transparent"
            style={{
              top: `${i * 2}%`,
              animation: `scanLine 8s linear infinite ${i * 0.1}s`,
              opacity: 0.2
            }}
          />
        ))}
      </div>

      {/* Glowing background */}
      <div className="absolute w-[120vh] h-[120vh] rounded-full bg-purple-900/5 animate-pulse-slow blur-xl" />
      <div className="absolute w-[100vh] h-[100vh] rounded-full bg-blue-800/5 animate-pulse-slow delay-75 blur-lg" />

      {/* Login Form Container */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className="max-w-md w-full relative"
      >
        {/* Glowing border effect */}
        <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/20 via-purple-500/20 to-cyan-500/20 rounded-xl blur-lg transform scale-105 animate-pulse-slow" />
        
        {/* Main form container */}
        <div className="relative bg-gray-900/90 backdrop-blur-xl p-8 rounded-xl border border-gray-700/50 shadow-2xl">
          <div className="text-center space-y-4">
            <motion.h2
              initial={{ y: -20 }}
              animate={{ y: 0 }}
              className="text-3xl font-bold bg-gradient-to-r from-cyan-400 via-purple-400 to-cyan-400 text-transparent bg-clip-text"
            >
              {isSignUp ? 'Create Account' : 'Welcome Back'}
            </motion.h2>
            <p className="text-gray-400">
              {isSignUp ? 'Start your journey with VECAID' : 'Continue your journey with VECAID'}
            </p>
          </div>

          <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
            <div className="space-y-4">
              <div className="relative group">
                <input
                  id="email"
                  name="email"
                  type="email"
                  autoComplete="email"
                  required
                  className="w-full px-4 py-3 bg-gray-800/50 border border-gray-700/50 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-transparent transition-all duration-200 backdrop-blur-sm"
                  placeholder="Email address"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
                <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-cyan-500/20 to-purple-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none" />
              </div>

              <div className="relative group">
                <input
                  id="password"
                  name="password"
                  type="password"
                  autoComplete={isSignUp ? 'new-password' : 'current-password'}
                  required
                  className="w-full px-4 py-3 bg-gray-800/50 border border-gray-700/50 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-transparent transition-all duration-200 backdrop-blur-sm"
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
                <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-purple-500/20 to-cyan-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none" />
              </div>
            </div>

            <AnimatePresence>
              {error && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="text-red-400 text-sm text-center bg-red-500/10 py-2 px-4 rounded-lg border border-red-500/20"
                >
                  {error}
                </motion.div>
              )}
            </AnimatePresence>

            <motion.button
              type="submit"
              disabled={isLoading}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className={`relative w-full group ${
                isLoading ? 'cursor-not-allowed' : 'cursor-pointer'
              }`}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-500 via-purple-500 to-cyan-500 rounded-lg blur transition-all duration-200 group-hover:blur-md" />
              <div className={`relative w-full py-3 bg-gray-900/90 rounded-lg border border-gray-700/50 text-white font-medium transition-all duration-200 group-hover:bg-gray-900/70 ${
                isLoading ? 'opacity-70' : ''
              }`}>
                {isLoading ? (
                  <div className="flex items-center justify-center space-x-2">
                    <div className="w-5 h-5 border-t-2 border-b-2 border-white rounded-full animate-spin" />
                    <span>{isSignUp ? 'Creating Account...' : 'Signing In...'}</span>
                  </div>
                ) : (
                  <span>{isSignUp ? 'Create Account' : 'Sign In'}</span>
                )}
              </div>
            </motion.button>

            <div className="text-center space-y-4">
              <motion.button
                type="button"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => navigate(isSignUp ? '/login' : '/signup')}
                className="text-sm text-cyan-400 hover:text-cyan-300 transition-colors duration-200"
              >
                {isSignUp
                  ? 'Already have an account? Sign in'
                  : "Don't have an account? Sign up"}
              </motion.button>
              
              <motion.button
                type="button"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => navigate('/developer')}
                className="text-sm text-purple-400 hover:text-purple-300 transition-colors duration-200 block w-full"
              >
                Developer Access
              </motion.button>
            </div>
          </form>
        </div>
      </motion.div>

      <style>{`
        @keyframes floatLine {
          0% { transform: translateX(-100%) rotate(35deg); }
          100% { transform: translateX(100%) rotate(35deg); }
        }

        @keyframes scanLine {
          0% { transform: translateY(100vh); }
          100% { transform: translateY(-100vh); }
        }

        .animate-pulse-slow {
          animation: pulse 3s infinite;
        }

        @keyframes pulse {
          0%, 100% { opacity: 0.5; }
          50% { opacity: 0.3; }
        }
      `}</style>
    </div>
  );
};

export default LoginPage; 