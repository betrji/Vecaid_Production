import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { FaUser, FaTwitter, FaLinkedin, FaGithub, FaChartLine, FaCoins, FaHistory, FaStar } from 'react-icons/fa';

interface UserProfile {
  email: string;
  username: string;
  bio: string;
  profilePhoto: string;
  subscriptionStatus: string;
  apiKey: string;
  socialMedia: {
    twitter?: string;
    linkedin?: string;
    github?: string;
  };
  investingExperience: {
    years: number;
    preferredSectors: string[];
    riskTolerance: 'Low' | 'Medium' | 'High';
    investmentStyle: 'Growth' | 'Value' | 'Dividend' | 'Day Trading';
    favoriteStocks: string[];
    portfolioSize: string;
  };
  preferences: {
    emailNotifications: boolean;
    darkMode: boolean;
    showAdvancedMetrics: boolean;
    receiveRecommendations: boolean;
  };
}

const ProfilePage: React.FC = () => {
  const navigate = useNavigate();
  const { isAuthenticated, loading: authLoading, logout } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [profile, setProfile] = useState<UserProfile>({
    email: 'user@example.com',
    username: 'Trader123',
    bio: 'Passionate about AI and stock market predictions.',
    profilePhoto: '',
    subscriptionStatus: 'Pro Plan',
    apiKey: '••••••••••••••••',
    socialMedia: {
      twitter: '@trader123',
      linkedin: 'linkedin.com/in/trader123',
      github: 'github.com/trader123'
    },
    investingExperience: {
      years: 3,
      preferredSectors: ['Technology', 'Healthcare', 'Finance'],
      riskTolerance: 'Medium',
      investmentStyle: 'Growth',
      favoriteStocks: ['AAPL', 'MSFT', 'TSLA'],
      portfolioSize: '$50,000 - $100,000'
    },
    preferences: {
      emailNotifications: true,
      darkMode: true,
      showAdvancedMetrics: true,
      receiveRecommendations: true
    }
  });

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      navigate('/login', { state: { from: '/profile' } });
    }
  }, [isAuthenticated, authLoading, navigate]);

  const handleLogout = async () => {
    try {
      await logout();
      navigate('/');
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  const handleSave = async () => {
    try {
      // Here you would typically make an API call to save the profile
      // For now, we'll just update the local state
      setIsEditing(false);
    } catch (error) {
      console.error('Failed to save profile:', error);
    }
  };

  const handleInputChange = (section: keyof UserProfile, field: string, value: any) => {
    setProfile(prev => ({
      ...prev,
      [section]: typeof prev[section] === 'object' 
        ? { ...prev[section], [field]: value }
        : value
    }));
  };

  const handleSocialMediaChange = (platform: keyof UserProfile['socialMedia'], value: string) => {
    setProfile(prev => ({
      ...prev,
      socialMedia: {
        ...prev.socialMedia,
        [platform]: value
      }
    }));
  };

  const handleExperienceChange = (field: keyof UserProfile['investingExperience'], value: any) => {
    setProfile(prev => ({
      ...prev,
      investingExperience: {
        ...prev.investingExperience,
        [field]: value
      }
    }));
  };

  const handlePreferenceChange = (key: keyof UserProfile['preferences']) => {
    setProfile(prev => ({
      ...prev,
      preferences: {
        ...prev.preferences,
        [key]: !prev.preferences[key]
      }
    }));
  };

  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 gradient-grid opacity-20" />
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/50 to-black" />

      {/* Main Content */}
      <div className="relative z-10 container mx-auto px-6 py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="bg-gray-800/50 rounded-2xl p-8 backdrop-blur-xl border border-gray-700"
        >
          <div className="flex items-center justify-between mb-8">
            <h1 className="text-3xl font-bold font-display">Profile</h1>
            <div className="flex items-center space-x-4">
              {isEditing ? (
                <>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={handleSave}
                    className="px-6 py-2 bg-green-500/20 text-green-400 rounded-lg hover:bg-green-500/30 transition-colors duration-200"
                  >
                    Save Changes
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setIsEditing(false)}
                    className="px-6 py-2 bg-gray-500/20 text-gray-400 rounded-lg hover:bg-gray-500/30 transition-colors duration-200"
                  >
                    Cancel
                  </motion.button>
                </>
              ) : (
                <>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setIsEditing(true)}
                    className="px-6 py-2 bg-purple-600/20 text-purple-400 rounded-lg hover:bg-purple-600/30 transition-colors duration-200"
                  >
                    Edit Profile
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={handleLogout}
                    className="px-6 py-2 bg-red-500/10 text-red-500 rounded-lg hover:bg-red-500/20 transition-colors duration-200"
                  >
                    Logout
                  </motion.button>
                </>
              )}
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Profile Section */}
            <div className="space-y-6">
              <div className="flex items-center space-x-6">
                <div className="relative group">
                  <div className="w-24 h-24 rounded-full bg-gray-700/50 overflow-hidden">
                    {profile.profilePhoto ? (
                      <img 
                        src={profile.profilePhoto} 
                        alt="Profile" 
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <FaUser className="w-full h-full p-6 text-gray-400" />
                    )}
                  </div>
                  {isEditing && (
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                      <button className="text-white text-sm">Change Photo</button>
                    </div>
                  )}
                </div>
                <div>
                  {isEditing ? (
                    <div className="space-y-2">
                      <input
                        type="text"
                        value={profile.username}
                        onChange={(e) => handleInputChange('username', 'username', e.target.value)}
                        className="w-full p-2 bg-gray-700/50 rounded border border-gray-600 text-white"
                      />
                      <input
                        type="email"
                        value={profile.email}
                        onChange={(e) => handleInputChange('email', 'email', e.target.value)}
                        className="w-full p-2 bg-gray-700/50 rounded border border-gray-600 text-white"
                      />
                    </div>
                  ) : (
                    <div>
                      <h2 className="text-xl font-display text-white mb-2">{profile.username}</h2>
                      <p className="text-gray-400">{profile.email}</p>
                    </div>
                  )}
                </div>
              </div>

              <div>
                <h3 className="text-lg font-display text-cyan-400 mb-2">Bio</h3>
                {isEditing ? (
                  <textarea
                    value={profile.bio}
                    onChange={(e) => handleInputChange('bio', 'bio', e.target.value)}
                    className="w-full p-2 bg-gray-700/50 rounded border border-gray-600 text-white h-24"
                  />
                ) : (
                  <p className="text-gray-300">{profile.bio}</p>
                )}
              </div>

              {/* Social Media Links */}
              <div>
                <h3 className="text-lg font-display text-cyan-400 mb-2">Social Media</h3>
                <div className="flex space-x-4">
                  {isEditing ? (
                    <>
                      <div className="flex-1">
                        <input
                          type="text"
                          value={profile.socialMedia.twitter}
                          onChange={(e) => handleSocialMediaChange('twitter', e.target.value)}
                          placeholder="Twitter handle"
                          className="w-full p-2 bg-gray-700/50 rounded border border-gray-600 text-white"
                        />
                      </div>
                      <div className="flex-1">
                        <input
                          type="text"
                          value={profile.socialMedia.linkedin}
                          onChange={(e) => handleSocialMediaChange('linkedin', e.target.value)}
                          placeholder="LinkedIn URL"
                          className="w-full p-2 bg-gray-700/50 rounded border border-gray-600 text-white"
                        />
                      </div>
                      <div className="flex-1">
                        <input
                          type="text"
                          value={profile.socialMedia.github}
                          onChange={(e) => handleSocialMediaChange('github', e.target.value)}
                          placeholder="GitHub username"
                          className="w-full p-2 bg-gray-700/50 rounded border border-gray-600 text-white"
                        />
                      </div>
                    </>
                  ) : (
                    <>
                      {profile.socialMedia.twitter && (
                        <a href={`https://twitter.com/${profile.socialMedia.twitter}`} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:text-blue-300">
                          <FaTwitter className="w-6 h-6" />
                        </a>
                      )}
                      {profile.socialMedia.linkedin && (
                        <a href={profile.socialMedia.linkedin} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:text-blue-300">
                          <FaLinkedin className="w-6 h-6" />
                        </a>
                      )}
                      {profile.socialMedia.github && (
                        <a href={profile.socialMedia.github} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-gray-300">
                          <FaGithub className="w-6 h-6" />
                        </a>
                      )}
                    </>
                  )}
                </div>
              </div>

              {/* Investing Experience */}
              <div>
                <h3 className="text-lg font-display text-cyan-400 mb-2">Investing Experience</h3>
                <div className="space-y-4">
                  {isEditing ? (
                    <>
                      <div className="flex items-center space-x-2">
                        <FaHistory className="text-purple-500" />
                        <input
                          type="number"
                          value={profile.investingExperience.years}
                          onChange={(e) => handleExperienceChange('years', parseInt(e.target.value))}
                          className="w-20 p-2 bg-gray-700/50 rounded border border-gray-600 text-white"
                        />
                        <span className="text-gray-300">years of experience</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <FaChartLine className="text-blue-500" />
                        <select
                          value={profile.investingExperience.riskTolerance}
                          onChange={(e) => handleExperienceChange('riskTolerance', e.target.value)}
                          className="p-2 bg-gray-700/50 rounded border border-gray-600 text-white"
                        >
                          <option value="Low">Low</option>
                          <option value="Medium">Medium</option>
                          <option value="High">High</option>
                        </select>
                        <span className="text-gray-300">Risk Tolerance</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <FaCoins className="text-yellow-500" />
                        <select
                          value={profile.investingExperience.portfolioSize}
                          onChange={(e) => handleExperienceChange('portfolioSize', e.target.value)}
                          className="p-2 bg-gray-700/50 rounded border border-gray-600 text-white"
                        >
                          <option value="$0 - $10,000">$0 - $10,000</option>
                          <option value="$10,000 - $50,000">$10,000 - $50,000</option>
                          <option value="$50,000 - $100,000">$50,000 - $100,000</option>
                          <option value="$100,000+">$100,000+</option>
                        </select>
                      </div>
                      <div className="flex items-center space-x-2">
                        <FaStar className="text-cyan-500" />
                        <select
                          value={profile.investingExperience.investmentStyle}
                          onChange={(e) => handleExperienceChange('investmentStyle', e.target.value)}
                          className="p-2 bg-gray-700/50 rounded border border-gray-600 text-white"
                        >
                          <option value="Growth">Growth</option>
                          <option value="Value">Value</option>
                          <option value="Dividend">Dividend</option>
                          <option value="Day Trading">Day Trading</option>
                        </select>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="flex items-center space-x-2">
                        <FaHistory className="text-purple-500" />
                        <span className="text-gray-300">{profile.investingExperience.years} years of experience</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <FaChartLine className="text-blue-500" />
                        <span className="text-gray-300">Risk Tolerance: {profile.investingExperience.riskTolerance}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <FaCoins className="text-yellow-500" />
                        <span className="text-gray-300">Portfolio Size: {profile.investingExperience.portfolioSize}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <FaStar className="text-cyan-500" />
                        <span className="text-gray-300">Investment Style: {profile.investingExperience.investmentStyle}</span>
                      </div>
                    </>
                  )}
                </div>
              </div>

              {/* Preferred Sectors */}
              <div>
                <h3 className="text-lg font-display text-cyan-400 mb-2">Preferred Sectors</h3>
                {isEditing ? (
                  <div className="flex flex-wrap gap-2">
                    {profile.investingExperience.preferredSectors.map((sector, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <input
                          type="text"
                          value={sector}
                          onChange={(e) => {
                            const newSectors = [...profile.investingExperience.preferredSectors];
                            newSectors[index] = e.target.value;
                            handleExperienceChange('preferredSectors', newSectors);
                          }}
                          className="px-3 py-1 bg-purple-500/20 text-purple-400 rounded-full text-sm"
                        />
                        <button
                          onClick={() => {
                            const newSectors = profile.investingExperience.preferredSectors.filter((_, i) => i !== index);
                            handleExperienceChange('preferredSectors', newSectors);
                          }}
                          className="text-red-500 hover:text-red-400"
                        >
                          ×
                        </button>
                      </div>
                    ))}
                    <button
                      onClick={() => {
                        const newSectors = [...profile.investingExperience.preferredSectors, ''];
                        handleExperienceChange('preferredSectors', newSectors);
                      }}
                      className="px-3 py-1 bg-purple-500/20 text-purple-400 rounded-full text-sm hover:bg-purple-500/30"
                    >
                      + Add Sector
                    </button>
                  </div>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {profile.investingExperience.preferredSectors.map((sector, index) => (
                      <span key={index} className="px-3 py-1 bg-purple-500/20 text-purple-400 rounded-full text-sm">
                        {sector}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              {/* Favorite Stocks */}
              <div>
                <h3 className="text-lg font-display text-cyan-400 mb-2">Favorite Stocks</h3>
                {isEditing ? (
                  <div className="flex flex-wrap gap-2">
                    {profile.investingExperience.favoriteStocks.map((stock, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <input
                          type="text"
                          value={stock}
                          onChange={(e) => {
                            const newStocks = [...profile.investingExperience.favoriteStocks];
                            newStocks[index] = e.target.value;
                            handleExperienceChange('favoriteStocks', newStocks);
                          }}
                          className="px-3 py-1 bg-blue-500/20 text-blue-400 rounded-full text-sm"
                        />
                        <button
                          onClick={() => {
                            const newStocks = profile.investingExperience.favoriteStocks.filter((_, i) => i !== index);
                            handleExperienceChange('favoriteStocks', newStocks);
                          }}
                          className="text-red-500 hover:text-red-400"
                        >
                          ×
                        </button>
                      </div>
                    ))}
                    <button
                      onClick={() => {
                        const newStocks = [...profile.investingExperience.favoriteStocks, ''];
                        handleExperienceChange('favoriteStocks', newStocks);
                      }}
                      className="px-3 py-1 bg-blue-500/20 text-blue-400 rounded-full text-sm hover:bg-blue-500/30"
                    >
                      + Add Stock
                    </button>
                  </div>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {profile.investingExperience.favoriteStocks.map((stock, index) => (
                      <span key={index} className="px-3 py-1 bg-blue-500/20 text-blue-400 rounded-full text-sm">
                        {stock}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Account Information and Preferences */}
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-semibold mb-4 text-cyan-400">Account Information</h2>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm text-gray-400">Email</label>
                    <div className="mt-1 text-lg text-gray-300">{profile.email}</div>
                  </div>
                  <div>
                    <label className="block text-sm text-gray-400">Subscription Status</label>
                    <div className="mt-1">
                      <span className="px-3 py-1 bg-purple-500/20 text-purple-400 rounded-full text-sm">
                        {profile.subscriptionStatus}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h2 className="text-xl font-semibold mb-4 text-cyan-400">API Access</h2>
                <div className="p-4 bg-gray-900/50 rounded-lg border border-gray-700">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-400">API Key</span>
                    <button className="text-sm text-cyan-500 hover:text-cyan-400">
                      Generate New Key
                    </button>
                  </div>
                  <div className="mt-2 font-mono text-sm bg-gray-900 p-2 rounded">
                    {profile.apiKey}
                  </div>
                </div>
              </div>

              <div>
                <h2 className="text-xl font-semibold mb-4 text-cyan-400">Preferences</h2>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Email Notifications</span>
                    <button 
                      onClick={() => handlePreferenceChange('emailNotifications')}
                      className={`w-12 h-6 rounded-full relative transition-colors ${
                        profile.preferences.emailNotifications ? 'bg-cyan-500' : 'bg-gray-700'
                      }`}
                    >
                      <span className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
                        profile.preferences.emailNotifications ? 'right-1' : 'left-1'
                      }`} />
                    </button>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Dark Mode</span>
                    <button 
                      onClick={() => handlePreferenceChange('darkMode')}
                      className={`w-12 h-6 rounded-full relative transition-colors ${
                        profile.preferences.darkMode ? 'bg-cyan-500' : 'bg-gray-700'
                      }`}
                    >
                      <span className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
                        profile.preferences.darkMode ? 'right-1' : 'left-1'
                      }`} />
                    </button>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Show Advanced Metrics</span>
                    <button 
                      onClick={() => handlePreferenceChange('showAdvancedMetrics')}
                      className={`w-12 h-6 rounded-full relative transition-colors ${
                        profile.preferences.showAdvancedMetrics ? 'bg-cyan-500' : 'bg-gray-700'
                      }`}
                    >
                      <span className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
                        profile.preferences.showAdvancedMetrics ? 'right-1' : 'left-1'
                      }`} />
                    </button>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Receive Recommendations</span>
                    <button 
                      onClick={() => handlePreferenceChange('receiveRecommendations')}
                      className={`w-12 h-6 rounded-full relative transition-colors ${
                        profile.preferences.receiveRecommendations ? 'bg-cyan-500' : 'bg-gray-700'
                      }`}
                    >
                      <span className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
                        profile.preferences.receiveRecommendations ? 'right-1' : 'left-1'
                      }`} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default ProfilePage; 