import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, useAnimation, AnimatePresence } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';
import { useDeveloper } from '../hooks/useDeveloper';
import '../styles/animations.css';

interface PricingCardProps {
  title: string;
  subtitle: string;
  features: string[];
  buttonText: string;
  isHighlighted?: boolean;
  onButtonClick: () => void;
}

// Pricing Card Component
const PricingCard: React.FC<PricingCardProps> = ({ title, subtitle, features, buttonText, isHighlighted = false, onButtonClick }) => (
  <motion.div
    whileHover={{ scale: 1.02 }}
    className={`relative rounded-xl p-6 ${
      isHighlighted 
        ? 'bg-gradient-to-br from-purple-600/20 to-blue-600/20 border border-purple-500/30' 
        : 'bg-gray-900/30 border border-gray-800/50'
    } group`}
  >
    {/* Glow effects - only visible on hover */}
    <span className="absolute -inset-2 rounded-3xl bg-gradient-to-r from-purple-500/30 via-cyan-500/40 to-pink-500/30 opacity-0 group-hover:opacity-50 blur-xl transition-all duration-500" 
      style={{ transform: 'scale(1.1, 0.9)' }}
    />
    <span className="absolute -inset-3 rounded-3xl bg-gradient-to-r from-blue-500/20 via-cyan-500/30 to-purple-500/20 opacity-0 group-hover:opacity-30 blur-2xl transition-all duration-700"
      style={{ transform: 'scale(1.2, 0.95)' }}
    />
    <div className="relative z-10">
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="text-xl font-bold text-white mb-2 font-display">{title}</h3>
          <p className="text-gray-400 text-sm">{subtitle}</p>
        </div>
        {isHighlighted && (
          <span className="bg-gradient-to-r from-purple-500 to-blue-500 text-white text-xs px-3 py-1 rounded-full font-display">
            Popular
          </span>
        )}
      </div>
      <ul className="space-y-3 mb-6">
        {features.map((feature, index) => (
          <li key={index} className="flex items-center text-gray-300">
            <svg className="w-5 h-5 mr-2 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
            </svg>
            {feature}
          </li>
        ))}
      </ul>
      <motion.button
        whileHover={{ scale: 1.02 }}
        className="relative w-full py-3 px-4 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-lg font-display font-medium hover:from-purple-700 hover:to-blue-700 transition-all duration-200 group"
        onClick={onButtonClick}
      >
        {buttonText}
        {/* Button glow effects - only visible on hover */}
        <span className="absolute -inset-2 rounded-full bg-gradient-to-r from-purple-500/30 via-cyan-500/40 to-pink-500/30 opacity-0 group-hover:opacity-50 blur-xl transition-all duration-500" 
          style={{ transform: 'scale(1.2, 0.8)' }}
        />
        <span className="absolute -inset-3 rounded-full bg-gradient-to-r from-blue-500/20 via-cyan-500/30 to-purple-500/20 opacity-0 group-hover:opacity-30 blur-2xl transition-all duration-700"
          style={{ transform: 'scale(1.4, 0.9)' }}
        />
      </motion.button>
    </div>
  </motion.div>
);

// Remove the InfinitySymbol component and replace with MetallicLogo
const MetallicLogo = () => {
  return (
    <div className="relative w-full h-full flex items-center justify-center">
      {/* Large-scale neural network effect */}
      <div className="fixed inset-0 overflow-hidden">
        {[...Array(40)].map((_, i) => (
          <div
            key={i}
            className="absolute bg-gradient-to-r from-transparent via-cyan-500/10 to-transparent"
            style={{
              width: '300%',
              height: '2px',
              left: '-100%',
              top: `${Math.random() * 100}%`,
              transform: 'rotate(35deg)',
              animation: `floatLine ${20 + Math.random() * 15}s linear infinite`,
              animationDelay: `${-Math.random() * 10}s`,
              opacity: 0.2
            }}
          />
        ))}
      </div>

      {/* Expanded data visualization grid */}
      <div className="fixed inset-0">
        <div className="absolute inset-0" style={{ perspective: '1000px' }}>
          {[...Array(100)].map((_, i) => (
      <motion.div
              key={i}
              className="absolute w-2 h-2 rounded-full bg-cyan-400/10"
              animate={{
                scale: [0, 1, 0],
                opacity: [0, 0.3, 0],
                z: [0, Math.random() * 100 - 50],
                x: [0, (Math.random() - 0.5) * 200],
                y: [0, (Math.random() - 0.5) * 200]
              }}
              transition={{
                duration: 4 + Math.random() * 3,
                repeat: Infinity,
                delay: i * 0.1
              }}
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`
              }}
            />
          ))}
        </div>
      </div>

      {/* Holographic scan lines */}
      <div className="fixed inset-0 pointer-events-none">
        {[...Array(50)].map((_, i) => (
          <div
            key={i}
            className="absolute w-full h-px bg-gradient-to-r from-transparent via-cyan-400/5 to-transparent"
            style={{
              top: `${i * 2}%`,
              animation: `scanLine 8s linear infinite ${i * 0.1}s`,
              opacity: 0.2
            }}
          />
        ))}
      </div>

      {/* Enhanced mystical background */}
      <div className="absolute w-[150vh] h-[150vh] animate-spin-slow opacity-30">
        {[...Array(24)].map((_, i) => (
          <div
            key={i}
            className="absolute w-full h-full"
            style={{
              transform: `rotate(${i * 15}deg)`,
              background: 'linear-gradient(transparent, rgba(6, 182, 212, 0.03), transparent)',
              animation: `pulse 3s infinite ${i * 0.1}s`
            }}
          />
        ))}
      </div>

      {/* Expanded legendary glow */}
      <div className="absolute w-[120vh] h-[120vh] rounded-full bg-cyan-900/5 animate-pulse-slow blur-xl" />
      <div className="absolute w-[100vh] h-[100vh] rounded-full bg-cyan-800/5 animate-pulse-slow delay-75 blur-lg" />
      
      {/* Main coin container */}
      <div className="relative w-96 h-96">
        {/* Dark chrome layers */}
        <div className="absolute inset-0 rounded-full bg-gradient-to-br from-[#1a1a1a] via-[#2a2a2a] to-[#1a1a1a] blur-2xl opacity-90" />
        <div className="absolute -inset-4 rounded-full bg-gradient-to-r from-[#1a1a1a] via-[#333333] to-[#1a1a1a] animate-pulse-slow blur-xl" />
        
        {/* Main coin body with dark chrome */}
        <div className="absolute inset-0 rounded-full shadow-2xl flex items-center justify-center overflow-hidden backdrop-blur-sm">
          {/* Dark chrome background */}
          <div className="absolute inset-0 bg-gradient-to-br from-[#1a1a1a] via-[#2a2a2a] to-[#1a1a1a] opacity-95">
            {/* Enhanced reflection lines */}
            {[...Array(8)].map((_, i) => (
              <div
                key={i}
                className="absolute inset-0 opacity-20"
                style={{
                  background: `linear-gradient(${120 + i * 12}deg, transparent 20%, rgba(255,255,255,0.2) 40%, transparent 60%)`,
                  animation: `moveLight 4s infinite ${i * 0.3}s`
                }}
              />
            ))}
          </div>

          {/* Refined 3D outline */}
          <div className="absolute inset-0 rounded-full border-8 border-[#333333]/20 backdrop-blur-xl" style={{ transform: 'translateZ(4px)' }} />
          <div className="absolute inset-0 rounded-full border-8 border-[#1a1a1a]/20 backdrop-blur-xl" style={{ transform: 'translateZ(-4px)' }} />
          
          {/* Refined coin content */}
          <div className="relative w-full h-full rounded-full flex items-center justify-center overflow-hidden">
            {/* Enhanced engraved pattern */}
            <div className="absolute inset-0">
              {[...Array(72)].map((_, i) => (
                <div
                  key={i}
                  className="absolute w-px h-full left-1/2 bg-gradient-to-b from-transparent via-[#404040]/20 to-transparent"
                  style={{ transform: `rotate(${i * 5}deg)` }}
                />
              ))}
            </div>

            {/* Refined center content */}
            <div className="relative z-10 flex flex-col items-center gap-8">
              {/* Enhanced VECAID text with glow effect */}
              <div className="relative group">
                <div className="text-4xl font-thin tracking-[0.3em] text-transparent bg-clip-text bg-gradient-to-r from-[#333333] via-cyan-500/30 to-[#333333] blur-[0.3px]">
                  VECAID
                </div>
                
                {/* Rainbow glow effect - only on hover */}
                <div className="absolute -inset-4 rounded-full opacity-0 group-hover:opacity-100 transition-all duration-500">
                  <div className="absolute inset-0 rounded-full bg-gradient-to-r from-purple-500/30 via-cyan-500/40 to-pink-500/30 blur-xl transition-all duration-1000" 
                    style={{ transform: 'scale(1.2, 0.8)' }}
                  />
                  <div className="absolute inset-0 rounded-full bg-gradient-to-r from-blue-500/20 via-cyan-500/30 to-purple-500/20 blur-2xl transition-all duration-1500"
                    style={{ transform: 'scale(1.4, 0.9)' }}
                  />
                  <div className="absolute inset-0 rounded-full bg-gradient-to-r from-pink-500/20 via-purple-500/30 to-blue-500/20 blur-3xl transition-all duration-2000"
                    style={{ transform: 'scale(1.6, 1)' }}
                  />
                </div>
              </div>
              
              {/* Enhanced infinity symbol */}
              <div className="relative w-32 h-16 opacity-60">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-12 h-12 border-[3px] border-[#333333]/60 rounded-full transform -translate-x-4 rotate-45 backdrop-blur-sm" />
                  <div className="w-12 h-12 border-[3px] border-[#333333]/60 rounded-full transform translate-x-4 rotate-45 backdrop-blur-sm" />
                </div>
                <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-cyan-500/5 to-transparent" />
              </div>
            </div>
          </div>
        </div>

        {/* Enhanced particle effects */}
        {[...Array(40)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 rounded-full bg-cyan-400/10"
            animate={{
              x: [0, Math.random() * 100 - 50],
              y: [0, Math.random() * 100 - 50],
              scale: [0, 1, 0],
              opacity: [0, 0.4, 0]
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: i * 0.1
            }}
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              filter: 'blur(0.5px)'
            }}
          />
        ))}

        {/* Enhanced rays */}
        <div className="absolute inset-0 animate-spin-slow">
          {[...Array(16)].map((_, i) => (
            <div
              key={i}
              className="absolute w-full h-0.5 bg-gradient-to-r from-transparent via-cyan-500/5 to-transparent blur-sm"
              style={{
                transform: `rotate(${i * 22.5}deg)`,
                transformOrigin: 'center'
              }}
            />
          ))}
        </div>
      </div>

      {/* Enhanced outer rings */}
      <div className="absolute w-[130vh] h-[130vh] rounded-full border border-[#333333]/5 animate-reverse-spin-slow blur-sm" />
      <div className="absolute w-[140vh] h-[140vh] rounded-full border border-[#1a1a1a]/5 animate-spin-slow blur-sm" />
    </div>
  );
};

interface FlipWordProps {
  words: string[];
  className: string;
}

const FlipWord: React.FC<FlipWordProps> = ({ words, className }) => {
  const [index, setIndex] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);

  // Calculate the width based on the longest word
  useEffect(() => {
    if (containerRef.current) {
      const temp = document.createElement('span');
      temp.style.visibility = 'hidden';
      temp.style.position = 'absolute';
      temp.style.fontSize = window.getComputedStyle(containerRef.current).fontSize;
      temp.style.fontFamily = window.getComputedStyle(containerRef.current).fontFamily;
      temp.style.fontWeight = window.getComputedStyle(containerRef.current).fontWeight;
      document.body.appendChild(temp);

      // Find the longest width
      let maxWidth = 0;
      words.forEach(word => {
        temp.textContent = word;
        maxWidth = Math.max(maxWidth, temp.offsetWidth);
      });

      document.body.removeChild(temp);
      if (containerRef.current) {
        containerRef.current.style.width = `${maxWidth + 4}px`; // Add small buffer
      }
    }
  }, [words]);

  useEffect(() => {
    const timer = setInterval(() => {
      setIndex((prev) => (prev + 1) % words.length);
    }, 3000);

    return () => clearInterval(timer);
  }, [words.length]);

  return (
    <div ref={containerRef} className="relative inline-flex items-center justify-center" style={{ minHeight: '1.2em' }}>
      <AnimatePresence mode="popLayout" initial={false}>
        <motion.div
          key={index}
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: -20, opacity: 0 }}
          transition={{ 
            duration: 0.5,
            ease: [0.19, 1, 0.22, 1],
            opacity: { duration: 0.35 }
          }}
          className={`${className} whitespace-nowrap absolute`}
        >
          {words[index]}
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

interface LandingPageProps {
  scrollTo?: string;
}

const LandingPage: React.FC<LandingPageProps> = ({ scrollTo }) => {
  const [devPasskey, setDevPasskey] = useState('');
  const [showDevLogin, setShowDevLogin] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const { isAuthenticated, isSubscribed, isDeveloper, user } = useAuth();
  const { authenticateWithKey, loading } = useDeveloper();

  // Refs for sections
  const featuresRef = useRef<HTMLDivElement>(null);
  const solutionsRef = useRef<HTMLDivElement>(null);
  const enterpriseRef = useRef<HTMLDivElement>(null);
  const pricingRef = useRef<HTMLDivElement>(null);
  const contactRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      setScrollPosition(window.scrollY);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (scrollTo) {
      const refs = {
        features: featuresRef,
        solutions: solutionsRef,
        enterprise: enterpriseRef,
        pricing: pricingRef,
        contact: contactRef
      };

      const targetRef = refs[scrollTo as keyof typeof refs];
      if (targetRef?.current) {
        targetRef.current.scrollIntoView({ behavior: 'smooth' });
      }
    }
  }, [scrollTo]);

  const handleNavigation = (path: string) => {
    if (path === '/prediction') {
      if (!isAuthenticated) {
        navigate('/login');
      } else if (!isSubscribed && !isDeveloper) {
        navigate('/subscription');
      } else {
        navigate(path);
      }
    } else {
      navigate(path);
    }
  };

  const handleDeveloperAuth = async (key: string) => {
    try {
      setError('');
      const success = await authenticateWithKey(key);
      if (success) {
        setShowDevLogin(false);
        setDevPasskey('');
        navigate('/prediction');
      }
    } catch (error: any) {
      console.error('Developer auth error:', error);
      setError(error.response?.data?.error || error.message || 'Authentication failed');
    }
  };

  return (
    <>
      <div className="min-h-screen bg-black relative overflow-hidden">
        {/* Navigation */}
        <nav className="relative z-50 px-6 py-4">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center space-x-8">
              {/* Logo */}
              <Link to="/" className="relative group">
                <h1 className="text-3xl font-display font-bold tracking-wide">
                  <span className="relative">
                    {/* Metallic highlight */}
                    <span className="relative text-transparent bg-clip-text bg-gradient-to-r from-gray-300 via-slate-100 to-gray-300">
                      VECAID
                    </span>
                  </span>
                </h1>
                
                {/* Refined glow effect */}
                <div className="absolute -inset-x-4 -inset-y-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-purple-500/10 via-cyan-500/15 to-purple-500/10 blur-md" />
                  <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-transparent via-cyan-500/10 to-transparent blur-sm" />
                </div>
              </Link>

              <div className="flex items-center space-x-6">
                {['Features', 'Solutions', 'Enterprise', 'Pricing'].map((item) => (
                  <motion.a
                    key={item}
                    whileHover={{ scale: 1.05 }}
                    onClick={() => handleNavigation(`/${item.toLowerCase()}`)}
                    className="relative text-gray-400 hover:text-cyan-500 transition-colors font-display text-sm tracking-wide cursor-pointer"
                  >
                    {item}
                  </motion.a>
                ))}
              </div>
            </div>

            <div className="flex items-center space-x-6">
              {isAuthenticated ? (
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  className="relative text-gray-400 hover:text-cyan-500 transition-colors font-display text-sm tracking-wide group flex items-center gap-2"
                  onClick={() => handleNavigation('/profile')}
                >
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    className="h-6 w-6" 
                    fill="none" 
                    viewBox="0 0 24 24" 
                    stroke="currentColor"
                  >
                    <path 
                      strokeLinecap="round" 
                      strokeLinejoin="round" 
                      strokeWidth={2} 
                      d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z" 
                    />
                  </svg>
                  Profile
                </motion.button>
              ) : (
                <>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    className="relative text-gray-400 hover:text-cyan-500 transition-colors font-display text-sm tracking-wide"
                    onClick={() => handleNavigation('/login')}
                  >
                    Log in
                  </motion.button>
                  <motion.button
            whileHover={{ scale: 1.05 }}
                    className="relative bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-500 px-6 py-2 rounded-lg font-display text-sm tracking-wide border border-cyan-500/20"
                    onClick={() => handleNavigation('/signup')}
                  >
                    Sign up
                  </motion.button>
                </>
              )}
            </div>
          </div>
        </nav>

        {/* Main content container */}
        <div className="relative z-10">
          {/* Dynamic spotlight background */}
          <div 
            className="fixed inset-0 pointer-events-none"
            style={{
              background: `radial-gradient(circle at 50% ${50 + scrollPosition * 0.1}%, rgba(192, 192, 192, 0.15) 0%, transparent 70%)`,
              transform: `translateY(${scrollPosition * 0.2}px)`,
              transition: 'background 0.3s ease-out'
            }}
          />
          
          {/* Additional background effects */}
          <div className="fixed inset-0 opacity-10">
            <div className="absolute inset-0" style={{
              backgroundImage: 'linear-gradient(transparent 97%, rgba(192, 192, 192, 0.1) 98%), linear-gradient(90deg, transparent 97%, rgba(192, 192, 192, 0.1) 98%)',
              backgroundSize: '40px 40px'
            }} />
          </div>

          {/* Background gradient - removing the dark overlay */}
          <div className="absolute inset-0 bg-gradient-to-br from-transparent via-black/5 to-transparent" />
          
          {/* Hero section */}
          <div className="relative z-10 pt-20 pb-32">
            <div className="max-w-7xl mx-auto px-6">
              <div className="text-center mb-16">
                <motion.h1 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6 }}
                  className="text-6xl font-light font-display mb-4 flex items-center justify-center space-x-4"
                >
                  <div className="inline-flex items-center">
                    <FlipWord 
                      words={["Predict", "Explore", "Analyze", "Discover", "Master", "Unlock"]}
                      className="text-transparent bg-clip-text bg-gradient-to-r from-gray-100 via-white to-gray-100 bg-[length:200%_auto] animate-gradient-x"
                    />
                  </div>
                  <div className="text-transparent bg-clip-text bg-gradient-to-r from-gray-100 via-white to-gray-100 animate-shine">
                    the
                  </div>
                  <div className="inline-flex items-center">
                    <FlipWord 
                      words={["Future", "Patterns", "Markets", "Trends", "Success"]}
                      className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-500 to-blue-500 to-purple-400 bg-[length:200%_auto] animate-gradient-x"
                    />
                  </div>
                  <div className="relative group">
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-gray-100 via-white to-gray-100 animate-shine">
                      with AI
                    </span>
                    <div className="absolute inset-0 bg-gradient-to-r from-gray-500/20 via-white/30 to-gray-500/20 opacity-0 group-hover:opacity-100 blur-xl transition-opacity duration-500"></div>
                  </div>
                </motion.h1>
                <motion.p 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                  className="text-xl text-gray-400 mb-4 max-w-2xl mx-auto"
                >
                  Harness the power of advanced analytics and machine learning to make accurate predictions and informed decisions.
                </motion.p>
              </div>

              {/* Product Showcase Section */}
              <div className="relative z-10">
                <div className="max-w-6xl mx-auto">
                  <div className="relative">
                    {/* Main Screenshot */}
                    <div className="relative rounded-xl overflow-hidden shadow-2xl border border-gray-800/50 bg-gray-900/30 backdrop-blur-sm">
                      <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 via-transparent to-blue-500/5" />
                      
                      {/* Browser-like header */}
                      <div className="relative px-4 py-3 bg-gray-900/50 border-b border-gray-800/50 flex items-center">
                        <div className="flex space-x-2">
                          <div className="w-3 h-3 rounded-full bg-red-500/50" />
                          <div className="w-3 h-3 rounded-full bg-yellow-500/50" />
                          <div className="w-3 h-3 rounded-full bg-green-500/50" />
                        </div>
                        <div className="absolute left-1/2 transform -translate-x-1/2 px-4 py-1 rounded-md bg-gray-800/30 text-gray-400 text-sm">
                          AI Prediction Interface
                        </div>
                      </div>

                      {/* Chat Interface Preview */}
                      <div className="p-6">
                        <div className="space-y-4">
                          {/* User Message */}
                          <div className="flex justify-end">
                            <div className="bg-purple-500/10 text-white rounded-2xl rounded-tr-sm px-6 py-3 max-w-md">
                              <p>Predict the market trend for renewable energy stocks in the next quarter</p>
                            </div>
                          </div>

                          {/* AI Response */}
                          <div className="flex justify-start">
                            <div className="bg-gray-800/50 text-gray-300 rounded-2xl rounded-tl-sm px-6 py-3 max-w-lg">
                              <div className="flex items-start space-x-2">
                                <div className="flex-shrink-0">
                                  <div className="w-8 h-8 rounded-lg bg-gradient-to-r from-purple-400 via-pink-500 to-blue-500 flex items-center justify-center">
                                    <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
                                    </svg>
                                  </div>
                                </div>
                                <div className="space-y-2">
                                  <p>Based on current market indicators and historical data analysis, renewable energy stocks show a strong potential for growth in Q3 2024. Key factors include:</p>
                                  <ul className="list-disc list-inside space-y-1 text-sm">
                                    <li>Increased government incentives</li>
                                    <li>Rising corporate sustainability commitments</li>
                                    <li>Technological advancements reducing costs</li>
                                  </ul>
                                  <div className="mt-3 bg-gray-900/30 rounded-lg p-3">
                                    <div className="h-32 relative">
                                      {/* Mockup Chart */}
                                      <div className="absolute inset-0 flex items-end space-x-1">
                                        {[...Array(20)].map((_, i) => (
                                          <div
                                            key={i}
                                            className="flex-1 bg-gradient-to-t from-purple-500/50 to-blue-500/50"
                                            style={{
                                              height: `${30 + Math.sin(i * 0.5) * 20 + Math.random() * 20}%`,
                                              transition: 'height 0.3s ease'
                                            }}
                                          />
                                        ))}
                                      </div>
                                    </div>
                                    <div className="text-xs text-gray-500 mt-2 text-center">Predicted Market Trend Q3 2024</div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Decorative Elements */}
                    <div className="absolute -inset-x-4 -inset-y-4 bg-gradient-to-r from-purple-500/10 via-transparent to-blue-500/10 rounded-xl blur-xl" style={{ transform: 'scale(1.05)' }} />
                    <div className="absolute -inset-x-4 -inset-y-4 bg-gradient-to-r from-blue-500/10 via-transparent to-purple-500/10 rounded-xl blur-xl animate-pulse" style={{ transform: 'scale(1.1)' }} />
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center justify-center mt-8 space-x-4">
                    <motion.button
                      onClick={() => handleNavigation('/prediction')}
                      className="relative flex justify-center py-3 px-6 text-sm font-medium rounded-md text-white bg-gradient-to-r from-purple-400 via-pink-500 to-blue-500 to-purple-400 bg-[length:200%_auto] animate-gradient-x hover:shadow-lg transition-all duration-200 min-w-[140px]"
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <span className="relative z-10">Get Started</span>
                      <div className="absolute inset-0 rounded-md bg-gradient-to-r from-purple-500/30 via-cyan-500/40 to-pink-500/30 blur-xl opacity-0 group-hover:opacity-50 transition-all duration-500" />
                    </motion.button>
                    <motion.button
                      onClick={() => setShowDevLogin(true)}
                      className="relative flex items-center justify-center py-3 px-6 border border-gray-700 text-sm font-medium rounded-md text-gray-300 bg-gray-900 hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 transition-colors duration-200 min-w-[180px]"
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <span className="flex items-center gap-3">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-400 group-hover:text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                        </svg>
                        Developer Access
                      </span>
                    </motion.button>
                  </div>

                  {/* Gradient Divider */}
                  <div className="relative my-12">
                    <div className="absolute inset-0 flex items-center">
                      <div className="w-full border-t border-gray-800/30"></div>
                    </div>
                    <div className="relative flex justify-center">
                      <div className="bg-black px-4">
                        <div className="h-4 w-4 rounded-full bg-gradient-to-r from-purple-500/20 via-cyan-500/20 to-blue-500/20"></div>
                      </div>
                    </div>
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-purple-500/5 to-transparent blur-sm"></div>
                  </div>

                  {/* Features Grid */}
                  <div className="grid grid-cols-3 gap-6">
                    <div className="bg-gray-900/20 backdrop-blur-sm rounded-xl p-6 border border-gray-800/30 hover:border-gray-700/30 transition-colors duration-300">
                      <div className="text-cyan-400 mb-3">
                        <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                        </svg>
                      </div>
                      <h3 className="text-lg font-display text-white mb-2">Real-time Analysis</h3>
                      <p className="text-gray-400 text-sm">Instant market insights and predictions</p>
                    </div>
                    <div className="bg-gray-900/20 backdrop-blur-sm rounded-xl p-6 border border-gray-800/30 hover:border-gray-700/30 transition-colors duration-300">
                      <div className="text-purple-400 mb-3">
                        <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M13 10V3L4 14h7v7l9-11h-7z" />
                        </svg>
                      </div>
                      <h3 className="text-lg font-display text-white mb-2">Advanced ML Models</h3>
                      <p className="text-gray-400 text-sm">Powered by cutting-edge AI algorithms</p>
                    </div>
                    <div className="bg-gray-900/20 backdrop-blur-sm rounded-xl p-6 border border-gray-800/30 hover:border-gray-700/30 transition-colors duration-300">
                      <div className="text-pink-400 mb-3">
                        <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                        </svg>
                      </div>
                      <h3 className="text-lg font-display text-white mb-2">Secure & Private</h3>
                      <p className="text-gray-400 text-sm">Enterprise-grade security measures</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* How VECAID Works Section */}
              <motion.div
                ref={featuresRef}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.6 }}
                className="mt-16 max-w-4xl mx-auto"
              >
                <h2 className="text-3xl font-display font-bold text-white mb-8 text-center flex items-center justify-center gap-2">
                  How 
                  <span className="relative group">
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-gray-300 via-gray-100 to-gray-300">
                      VECAID
                    </span>
                    
                    <span className="absolute -inset-2 rounded-full bg-gradient-to-r from-purple-500/30 via-cyan-500/40 to-pink-500/30 opacity-0 group-hover:opacity-50 blur-xl transition-all duration-1000 animate-glow-slow"
                      style={{ transform: 'scale(1.2, 0.8)' }}
                    />
                    <span className="absolute -inset-3 rounded-full bg-gradient-to-r from-blue-500/20 via-cyan-500/30 to-purple-500/20 opacity-0 group-hover:opacity-30 blur-2xl transition-all duration-1500 animate-pulse-slower"
                      style={{ transform: 'scale(1.4, 0.9)' }}
                    />
                  </span>
                  Works
                </h2>
                <div className="grid md:grid-cols-3 gap-8">
                  <div className="bg-gray-900/30 p-6 rounded-xl border border-gray-800/50">
                    <div className="text-purple-500 mb-4">
                      <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                      </svg>
                    </div>
                    <h3 className="text-xl font-display text-white mb-3">Data Analysis</h3>
                    <p className="text-gray-400">Our AI processes vast amounts of data to identify patterns and trends, providing you with actionable insights.</p>
                  </div>
                  <div className="bg-gray-900/30 p-6 rounded-xl border border-gray-800/50">
                    <div className="text-blue-500 mb-4">
                      <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
                      </svg>
                    </div>
                    <h3 className="text-xl font-display text-white mb-3">Predictive Modeling</h3>
                    <p className="text-gray-400">Advanced machine learning algorithms generate accurate predictions and forecasts for your business needs.</p>
                  </div>
                  <div className="bg-gray-900/30 p-6 rounded-xl border border-gray-800/50">
                    <div className="text-pink-500 mb-4">
                      <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                      </svg>
                    </div>
                    <h3 className="text-xl font-display text-white mb-3">Secure & Reliable</h3>
                    <p className="text-gray-400">Enterprise-grade security ensures your data is protected while our systems maintain 99.9% uptime.</p>
                  </div>
                </div>
          </motion.div>

              {/* Decorative divider */}
              <div className="relative h-12 flex items-center justify-center">
                <div className="absolute w-1/3 h-px bg-gradient-to-r from-transparent via-gray-700 to-transparent" />
                <div className="absolute bg-black px-4">
                  <svg className="w-6 h-6 text-gray-700" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <path d="M18.6 18.6L12 12m0 0L5.4 5.4M12 12l6.6-6.6M12 12l-6.6 6.6" strokeWidth="1.5" strokeLinecap="round" />
                    <path d="M5.4 18.6L12 12m0 0l6.6-6.6" strokeWidth="1.5" strokeLinecap="round" />
                  </svg>
                </div>
              </div>

              {/* Inspiring tagline */}
          <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="text-center mt-8 mb-8"
              >
                <h2 className="text-3xl font-display text-white mb-8 text-center">
                  Invest with Confidence, Clarity, and Infinite Potential
                </h2>
                <p className="text-gray-500 mt-2 font-display tracking-wide">
                  Your journey to mastering time begins here
            </p>
          </motion.div>
            </div>
          </div>

          {/* Pricing Section */}
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <PricingCard
              title="Basic"
              subtitle="For individuals and small teams"
              features={[
                "Basic predictions",
                "Standard analytics",
                "Email support",
                "1 user"
              ]}
              buttonText="Start Free Trial"
              onButtonClick={() => navigate('/signup')}
            />
            <PricingCard
              title="Pro"
              subtitle="For growing businesses"
              features={[
                "Advanced predictions",
                "Custom analytics",
                "Priority support",
                "5 users"
              ]}
              buttonText="Start Free Trial"
              onButtonClick={() => navigate('/signup')}
              isHighlighted={true}
            />
            <PricingCard
              title="Enterprise"
              subtitle="For large organizations"
              features={[
                "Custom solutions",
                "Dedicated support",
                "API access",
                "Unlimited users"
              ]}
              buttonText="Contact Sales"
              onButtonClick={() => navigate('/contact')}
            />
          </div>

          {/* Detailed How VECAID Works Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.8 }}
            className="mt-24 max-w-4xl mx-auto"
          >
            <h2 className="text-3xl font-display font-bold text-white mb-12 text-center flex items-center justify-center gap-2">
              Dive Deeper into{" "}
              <span className="relative group">
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-gray-300 via-gray-100 to-gray-300">
                  VECAID
                </span>
                <span className="absolute -inset-2 rounded-full bg-gradient-to-r from-purple-500/30 via-cyan-500/40 to-pink-500/30 opacity-0 group-hover:opacity-50 blur-xl transition-all duration-1000 animate-glow-slow" 
                  style={{ transform: 'scale(1.2, 0.8)' }}
                />
                <span className="absolute -inset-3 rounded-full bg-gradient-to-r from-blue-500/20 via-cyan-500/30 to-purple-500/20 opacity-0 group-hover:opacity-30 blur-2xl transition-all duration-1500 animate-pulse-slower"
                  style={{ transform: 'scale(1.4, 0.9)' }}
                />
              </span>
            </h2>
            <div className="space-y-8">
              <div className="bg-gray-900/30 p-8 rounded-xl border border-gray-800/50">
                <h3 className="text-2xl font-display text-white mb-4">Advanced AI Technology</h3>
                <p className="text-gray-400 mb-4">VECAID leverages cutting-edge artificial intelligence to analyze complex data sets and generate accurate predictions. Our system continuously learns and improves, ensuring you always have the most up-to-date insights.</p>
                <ul className="space-y-3 text-gray-400">
                  <li className="flex items-center">
                    <svg className="w-5 h-5 mr-2 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    Real-time data processing and analysis
                  </li>
                  <li className="flex items-center">
                    <svg className="w-5 h-5 mr-2 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    Machine learning algorithms for pattern recognition
                  </li>
                  <li className="flex items-center">
                    <svg className="w-5 h-5 mr-2 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    Automated model optimization and updates
                  </li>
                </ul>
              </div>

              <div className="bg-gray-900/30 p-8 rounded-xl border border-gray-800/50">
                <h3 className="text-2xl font-display text-white mb-4">Seamless Integration</h3>
                <p className="text-gray-400 mb-4">VECAID seamlessly integrates with your existing systems and workflows. Our platform is designed to work with your current tools, making adoption smooth and efficient.</p>
                <ul className="space-y-3 text-gray-400">
                  <li className="flex items-center">
                    <svg className="w-5 h-5 mr-2 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    API-first architecture for easy integration
                  </li>
                  <li className="flex items-center">
                    <svg className="w-5 h-5 mr-2 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    Support for multiple data formats and sources
                  </li>
                  <li className="flex items-center">
                    <svg className="w-5 h-5 mr-2 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    Customizable dashboards and reports
                  </li>
                </ul>
              </div>

              <div className="bg-gray-900/30 p-8 rounded-xl border border-gray-800/50">
                <h3 className="text-2xl font-display text-white mb-4">Enterprise-Grade Security</h3>
                <p className="text-gray-400 mb-4">Your data security is our top priority. VECAID implements industry-leading security measures to protect your sensitive information and ensure compliance with global standards.</p>
                <ul className="space-y-3 text-gray-400">
                  <li className="flex items-center">
                    <svg className="w-5 h-5 mr-2 text-pink-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    End-to-end encryption for all data
                  </li>
                  <li className="flex items-center">
                    <svg className="w-5 h-5 mr-2 text-pink-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    Regular security audits and updates
                  </li>
                  <li className="flex items-center">
                    <svg className="w-5 h-5 mr-2 text-pink-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    Compliance with GDPR and other regulations
                  </li>
                </ul>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Developer Login Modal */}
        <AnimatePresence>
          {showDevLogin && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 flex items-center justify-center z-50"
            >
              <motion.div 
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.95, opacity: 0 }}
                className="bg-gray-900 p-6 rounded-lg shadow-xl w-96"
              >
                <h3 className="text-xl font-bold mb-4 text-white">Developer Access</h3>
                {error && (
                  <div className="mb-4 p-3 bg-red-500/10 border border-red-500/20 rounded text-red-400 text-sm">
                    {error}
                  </div>
                )}
                <input
                  type="password"
                  value={devPasskey}
                  onChange={(e) => setDevPasskey(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleDeveloperAuth(devPasskey)}
                  placeholder="Enter developer key"
                  className="w-full p-2 mb-4 bg-gray-800 rounded border border-gray-700 text-white placeholder-gray-500 focus:outline-none focus:border-purple-500"
                />
                <div className="flex justify-end gap-2">
                  <button
                    onClick={() => {
                      setShowDevLogin(false);
                      setDevPasskey('');
                      setError('');
                    }}
                    className="px-4 py-2 text-gray-400 hover:text-white transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => handleDeveloperAuth(devPasskey)}
                    className="px-4 py-2 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded hover:from-purple-700 hover:to-blue-700 transition-all duration-200 disabled:opacity-50"
                    disabled={!devPasskey.trim() || loading}
                  >
                    {loading ? (
                      <div className="flex items-center justify-center">
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                      </div>
                    ) : (
                      'Login'
                    )}
                  </button>
                </div>
              </motion.div>
      </motion.div>
          )}
        </AnimatePresence>

        {/* Add Profile Section for Authenticated Users */}
        {isAuthenticated && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="relative z-10 container mx-auto px-6 py-16 mt-16"
          >
            <div className="bg-gray-800/50 rounded-2xl p-8 backdrop-blur-xl border border-gray-700">
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-2xl font-bold font-display text-white">Welcome back, {user?.email}</h2>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleNavigation('/profile')}
                  className="px-6 py-2 bg-purple-600/20 text-purple-400 rounded-lg hover:bg-purple-600/30 transition-colors duration-200"
                >
                  View Profile
                </motion.button>
              </div>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="bg-gray-900/50 p-6 rounded-lg">
                  <h3 className="text-lg font-display text-cyan-400 mb-2">Recent Activity</h3>
                  <p className="text-gray-400">View your prediction history and saved stocks</p>
                </div>
                <div className="bg-gray-900/50 p-6 rounded-lg">
                  <h3 className="text-lg font-display text-cyan-400 mb-2">Preferences</h3>
                  <p className="text-gray-400">Customize your experience and notifications</p>
                </div>
                <div className="bg-gray-900/50 p-6 rounded-lg">
                  <h3 className="text-lg font-display text-cyan-400 mb-2">Social</h3>
                  <p className="text-gray-400">Connect with other traders and share insights</p>
                </div>
              </div>
            </div>
          </motion.div>
        )}
    </div>

      <style>{`
        @keyframes glow-slow {
          0%, 100% {
            opacity: 0.5;
            transform: scale(1.2, 0.8);
          }
          50% {
            opacity: 0.8;
            transform: scale(1.3, 0.9);
          }
        }
        
        @keyframes pulse-slower {
          0%, 100% {
            opacity: 0.3;
            transform: scale(1.4, 0.9);
          }
          50% {
            opacity: 0.5;
            transform: scale(1.5, 1);
          }
        }
        
        @keyframes pulse-slowest {
          0%, 100% {
            opacity: 0.2;
            transform: scale(1.6, 1);
          }
          50% {
            opacity: 0.4;
            transform: scale(1.7, 1.1);
          }
        }

        @keyframes gradient-x {
          0% {
            background-position: 0% 50%;
          }
          50% {
            background-position: 100% 50%;
          }
          100% {
            background-position: 0% 50%;
          }
        }
        
        .animate-gradient-x {
          animation: gradient-x 8s linear infinite;
          background-size: 200% auto;
          transition: all 0.3s ease;
        }
        
        .animate-gradient-x:hover {
          background-position: 100% 50%;
          animation-play-state: paused;
        }
        
        .animate-glow-slow {
          animation: glow-slow 3s infinite;
        }
        
        .animate-pulse-slower {
          animation: pulse-slower 4s infinite;
        }
        
        .animate-pulse-slowest {
          animation: pulse-slowest 5s infinite;
        }

        @keyframes shine {
          0% {
            background-position: -200% center;
          }
          100% {
            background-position: 200% center;
          }
        }

        .animate-shine {
          animation: shine 8s linear infinite;
          background-size: 200% auto;
        }
      `}</style>
    </>
  );
};

export default LandingPage;
