import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { FaCheckCircle } from 'react-icons/fa';
import { motion } from 'framer-motion';
import axios from 'axios';
import { LoadingSpinner } from '../App';
import { api, endpoints } from '../api/config';

const SubscriptionPage: React.FC = () => {
  const { user, isAuthenticated, setUser } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Check if we're returning from a successful subscription
    const urlParams = new URLSearchParams(window.location.search);
    const sessionId = urlParams.get('session_id');
    
    if (sessionId) {
      setLoading(true);
      // Verify the subscription status
      axios.get(`http://localhost:8080/api/subscription/success?session_id=${sessionId}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('authToken')}`
        }
      })
      .then(response => {
        if (response.data.success) {
          // Update user subscription status
          const updatedUser = user ? { ...user, isSubscribed: true } : null;
          setUser(updatedUser);
          navigate('/prediction', { replace: true });
        } else {
          setError('Failed to verify subscription. Please contact support.');
        }
      })
      .catch(err => {
        setError('An error occurred while verifying your subscription.');
        console.error('Subscription verification error:', err);
      })
      .finally(() => setLoading(false));
    }
  }, [navigate, user, setUser]);

  const features = [
    'Unlimited AI-Powered Stock Predictions',
    'Real-Time Market Analysis',
    'Advanced Technical Indicators',
    'Portfolio Optimization Tools',
    'Priority Customer Support',
    'Early Access to New Features',
    'Custom Alert System',
    'Detailed Market Reports'
  ];

  const handleSubscriptionSuccess = async (sessionId: string) => {
    try {
        await api.get(`/api/subscription/success?session_id=${sessionId}`);
        // Update subscription status in context
        if (user) {
            setUser({ ...user, isSubscribed: true });
        }
        navigate('/prediction');
    } catch (error) {
        console.error('Error processing subscription:', error);
        setError('Failed to process subscription. Please try again.');
    }
  };

  const handleSubscribe = async () => {
    try {
        setLoading(true);
        const response = await api.post('/api/subscription/create-checkout');
        window.location.href = response.data.url;
    } catch (error) {
        console.error('Error creating checkout session:', error);
        setError('Failed to start subscription process. Please try again.');
        setLoading(false);
    }
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="min-h-screen bg-[#0A0A0A] py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <motion.h1 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-4xl md:text-5xl font-display font-bold bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 text-transparent bg-clip-text"
          >
            Upgrade to VECAID Premium
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="mt-4 text-xl font-display text-gray-300"
          >
            Unlock the full potential of AI-powered stock predictions
          </motion.p>
        </div>

        {error && (
          <div className="mt-8 max-w-md mx-auto bg-red-900/50 text-white p-4 rounded-lg border border-red-500 font-display">
            {error}
          </div>
        )}

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-gradient-to-r from-purple-900/20 via-pink-900/20 to-red-900/20 rounded-2xl p-8 backdrop-blur-sm border border-purple-500/30"
        >
          <div className="flex flex-col items-center">
            <div className="flex items-center gap-4 mb-8 font-display">
              <span className="text-gray-400 line-through text-2xl">$24.99/mo</span>
              <span className="text-4xl font-bold text-white">$9.99/mo</span>
              <span className="bg-purple-500 text-white text-sm px-3 py-1 rounded-full">60% OFF</span>
            </div>

            <div className="grid md:grid-cols-2 gap-6 w-full mb-8">
              {features.map((feature, index) => (
                <motion.div
                  key={feature}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + index * 0.1 }}
                  className="flex items-center space-x-3 font-display"
                >
                  <FaCheckCircle className="text-purple-400 flex-shrink-0" />
                  <span className="text-gray-300">{feature}</span>
                </motion.div>
              ))}
            </div>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleSubscribe}
              disabled={user?.isSubscribed}
              className={`w-full md:w-auto px-8 py-4 rounded-xl text-lg font-display font-semibold text-white
                ${user?.isSubscribed
                  ? 'bg-gray-600 cursor-not-allowed'
                  : 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700'
                } transition duration-200 shadow-lg`}
            >
              {user?.isSubscribed ? 'Already Subscribed' : 'Start Premium Now'}
            </motion.button>

            <p className="mt-4 text-gray-400 text-sm font-display">
              Cancel anytime. 30-day money-back guarantee.
            </p>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="mt-12 text-center text-gray-400 font-display"
        >
          <p>Need help? Contact our support team at support@vecaid.ai</p>
        </motion.div>
      </div>
    </div>
  );
};

export default SubscriptionPage; 