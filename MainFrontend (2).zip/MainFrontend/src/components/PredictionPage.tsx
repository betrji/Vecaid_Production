import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import axios, { CancelTokenSource } from 'axios';
import { useAuth } from '../contexts/AuthContext';
import { useChatHistory } from '../contexts/ChatHistoryContext';
import '../styles/animations.css';
import { api, API_URL, endpoints } from '../api/config';

interface Message {
  type: 'user' | 'assistant' | 'loading' | 'terminal' | 'chart' | 'prediction';
  content: string | string[];
  timestamp: Date;
  loadingStage?: number;
  progress?: number;
  timeRemaining?: number;
  chartUrl?: string;
  prediction?: PredictionResult;
  indicators?: {
    name: string;
    value: string;
    trend: 'up' | 'down' | 'neutral';
  }[];
}

interface PredictionResult {
  ticker: string;
  training_info: {
    training_time: number;
    final_loss: number;
    model_type: string;
  };
  ml_prediction: {
    direction: 'up' | 'down';
    confidence: number;
    target_price: number;
    predicted_move: number;
    predicted_date: string;
  };
  backtest_results: {
    statistics: {
      accuracy_percentage: number;
      mean_absolute_error: number;
      rmse_price: number;
    };
    predictions: number[];
    actuals: number[];
  };
  technical_indicators: {
    rsi: number;
    macd: number;
    signal: number;
    bollinger_bands: {
      upper: number;
      middle: number;
      lower: number;
    };
  };
  error?: string;
}

const WELCOME_MESSAGE = `Welcome to VECAID AI! 🚀 I'm your advanced stock prediction assistant powered by state-of-the-art machine learning models.

I can help you with:

🔮 AI-Powered Stock Predictions
📊 Real-Time Market Analysis
📈 Technical Indicators (RSI, MACD, Bollinger Bands)
📉 Backtesting Results
💡 Trading Insights
📊 Price Target Predictions

To get started:
1. Enter a stock ticker (e.g., "AAPL" or "analyze AAPL")
2. Ask questions about the analysis (e.g., "explain the technical indicators")
3. Request specific insights (e.g., "what's the confidence level?")

Just type your question or ticker symbol below!`;

const PredictionPage: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([{
    type: 'assistant',
    content: WELCOME_MESSAGE,
    timestamp: new Date()
  }]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingStage, setLoadingStage] = useState(0);
  const [progress, setProgress] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState(45);
  const [selectedDate, setSelectedDate] = useState<string>('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const cancelTokenRef = useRef<CancelTokenSource | null>(null);
  const { isAuthenticated, loading: authLoading, isSubscribed, isDeveloper, user } = useAuth();
  const { isHistoryOpen, setIsHistoryOpen } = useChatHistory();
  const chatContainerRef = useRef<HTMLDivElement>(null);

  // Group messages by date for the dropdown
  const messagesByDate = useMemo(() => {
    const groups: { [key: string]: Message[] } = {};
    messages.forEach(message => {
      const date = message.timestamp.toLocaleDateString();
      if (!groups[date]) {
        groups[date] = [];
      }
      groups[date].push(message);
    });
    return groups;
  }, [messages]);

  // Load selected chat history
  const loadChatHistory = (date: string) => {
    setSelectedDate(date);
    // The messages are already in the state, we just need to scroll to them
    const targetMessage = messagesByDate[date][0];
    const targetElement = document.querySelector(`[data-timestamp="${targetMessage.timestamp.getTime()}"]`);
    if (targetElement) {
      targetElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      navigate('/login', { state: { from: '/prediction' } });
      return;
    }

    if (!authLoading && !isDeveloper && !isSubscribed) {
      navigate('/subscription');
      return;
    }
  }, [isAuthenticated, authLoading, isDeveloper, isSubscribed, navigate]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Add cleanup effect for page reload/unmount
  useEffect(() => {
    const handleBeforeUnload = () => {
      if (cancelTokenRef.current) {
        cancelTokenRef.current.cancel('Operation cancelled by page reload');
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
      if (cancelTokenRef.current) {
        cancelTokenRef.current.cancel('Component unmounted');
      }
    };
  }, []);

  const loadingMessages = [
    "Getting basic prediction...",
    "Training ML models...",
    "Starting training of the ML model...",
    "Downloading daily data...",
    "Downloading weekly data...",
    "Computing technical indicators on daily+weekly merged data...",
    "Downloading intraday 5-minute data...",
    "Creating feature vectors and target values...",
    "Applying PCA (retain 95% variance)...",
    "Starting Bayesian optimization for XGBoost hyperparameters...",
    "Training GRU model...",
    "Training CNN-LSTM model...",
    "Training Transformer model...",
    "Training XGBoost model...",
    "Combining predictions with meta-model...",
    "Generating visualization charts...",
    "Computing final prediction metrics..."
  ];

  const processingMessages = [
    "127.0.0.1 - - [16/Apr/2025 20:25:47] 'POST /api/info HTTP/1.1' 200 -",
    "Training ML models...",
    "Starting training of the ML model...",
    "Downloading daily data...",
    "[************************************************] 1 of 1 completed",
    "Downloading weekly data...",
    "Computing technical indicators on daily+weekly merged data...",
    "Downloading intraday 5-minute data...",
    "Creating feature vectors and target values...",
    "Applying PCA (retain 95% variance)...",
    "PCA reduced input dimension to: 10",
    "Starting Bayesian optimization for XGBoost hyperparameters..."
  ];

  useEffect(() => {
    let interval: number;
    let progressInterval: number;
    let processingInterval: number;
    
    if (loading) {
      // Message rotation interval - show a new message every 3 seconds
      interval = window.setInterval(() => {
        setLoadingStage((prev: number) => (prev + 1) % loadingMessages.length);
      }, 3000);

      // Processing message interval
      processingInterval = window.setInterval(() => {
        setMessages(prev => {
          const lastMessage = prev[prev.length - 1];
          if (lastMessage.type === 'loading') {
            const currentStage = lastMessage.loadingStage || 0;
            const processingMessage = processingMessages[currentStage % processingMessages.length];
            return [...prev, {
              type: 'loading',
              content: processingMessage,
              timestamp: new Date(),
              loadingStage: currentStage,
              progress: lastMessage.progress,
              timeRemaining: lastMessage.timeRemaining
            }];
          }
          return prev;
        });
      }, 1000);

      // Progress and time update interval
      progressInterval = window.setInterval(() => {
        setProgress((prev: number) => {
          const newProgress = prev + 1;
          const newTimeRemaining = Math.max(0, Math.ceil(30 * (100 - newProgress) / 100));
          setTimeRemaining(newTimeRemaining);
          return Math.min(99, newProgress);
        });
      }, 300); // Update every 300ms for smoother progress
    }

    return () => {
      clearInterval(interval);
      clearInterval(progressInterval);
      clearInterval(processingInterval);
    };
  }, [loading]);

  const formatTimeRemaining = (seconds: number) => {
    if (seconds <= 0) return "Finalizing prediction...";
    return `⏱️ Estimated completion in ${seconds} seconds`;
  };

  const renderTerminalLine = (content: string, index: number) => {
    const isCommand = content.startsWith("$");
    const isProgress = content.includes("[") && content.includes("]");
    const isError = content.toLowerCase().includes("error");
    const isSuccess = content.includes("200") || content.includes("completed");
    
    return (
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.3, delay: index * 0.1 }}
        className="font-mono text-sm"
      >
        {/* Terminal prefix */}
        <span className="text-cyan-500/60 terminal-text">
          {isCommand ? "┌─[" : "└─["}
        </span>
        <span className="text-purple-400/60 terminal-text vecaid-text">VECAID</span>
        <span className="text-cyan-500/60 terminal-text">]─[</span>
        <span className="text-blue-400/60 terminal-text">{new Date().toLocaleTimeString()}</span>
        <span className="text-cyan-500/60 terminal-text">]</span>
        
        {/* Command/output content */}
        <span className={`ml-2 ${
          isCommand ? 'text-green-400/90' :
          isError ? 'text-red-400' :
          isSuccess ? 'text-emerald-400' :
          isProgress ? 'text-cyan-300' :
          'text-gray-300/90'
        }`}>
          {content}
        </span>
        
        {/* Progress bar animation for progress lines */}
        {isProgress && (
          <div className="mt-1 w-full bg-gray-800/50 rounded-full h-1 overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-cyan-500 via-purple-500 to-cyan-500"
              initial={{ width: "0%" }}
              animate={{ width: "100%" }}
              transition={{ duration: 1 }}
            />
          </div>
        )}
      </motion.div>
    );
  };

  const handleCancel = async () => {
    if (!loading) return;

    try {
      // Cancel any existing request
      if (cancelTokenRef.current) {
        cancelTokenRef.current.cancel('Operation cancelled by user');
        cancelTokenRef.current = null;
      }

      // Call backend to cancel the prediction task
      const currentTicker = messages[messages.length - 2]?.content; // Get the last user message (ticker)
      if (typeof currentTicker === 'string') {
        await api.post(endpoints.predictions.cancel(currentTicker));
        setMessages(prev => [...prev, {
          type: 'terminal',
          content: [
            `[INFO] Prediction cancelled for ${currentTicker}`,
            `[INFO] Time circuits reset`,
            `[INFO] Ready for new prediction`
          ],
          timestamp: new Date()
        }]);
      }

      setLoading(false);
      setProgress(0);
      setTimeRemaining(45);
      setLoadingStage(0);
    } catch (error) {
      console.error('Error cancelling prediction:', error);
      setMessages(prev => [...prev, {
        type: 'terminal',
        content: [
          `[ERROR] Failed to cancel prediction`,
          `[INFO] Please try again`
        ],
        timestamp: new Date()
      }]);
    }
  };

  const handleQuery = async (query: string) => {
    try {
      // Add user message
      setMessages(prev => [...prev, {
        type: 'user',
        content: query,
        timestamp: new Date()
      }]);

      // Get the last prediction result
      const lastPrediction = messages
        .filter(m => m.type === 'prediction')
        .pop()?.prediction;

      if (!lastPrediction) {
        setMessages(prev => [...prev, {
          type: 'assistant',
          content: 'Please analyze a stock first before asking questions about predictions.',
          timestamp: new Date()
        }]);
        return;
      }

      // Process the query
      const queryLower = query.toLowerCase();
      let response = '';

      if (queryLower.includes('technical') || queryLower.includes('indicator')) {
        response = `Technical Indicators for ${lastPrediction.ticker}:
        
1. RSI (Relative Strength Index):
   - Value: ${lastPrediction.technical_indicators.rsi.toFixed(2)}
   - Signal: ${lastPrediction.technical_indicators.rsi > 70 ? 'Overbought' : 
             lastPrediction.technical_indicators.rsi < 30 ? 'Oversold' : 'Neutral'}

2. MACD (Moving Average Convergence Divergence):
   - Value: ${lastPrediction.technical_indicators.macd.toFixed(2)}
   - Signal Line: ${lastPrediction.technical_indicators.signal.toFixed(2)}
   - Trend: ${lastPrediction.technical_indicators.macd > lastPrediction.technical_indicators.signal ? 
            'Bullish' : 'Bearish'}

3. Bollinger Bands:
   - Upper: $${lastPrediction.technical_indicators.bollinger_bands.upper.toFixed(2)}
   - Middle: $${lastPrediction.technical_indicators.bollinger_bands.middle.toFixed(2)}
   - Lower: $${lastPrediction.technical_indicators.bollinger_bands.lower.toFixed(2)}
   - Current Price Position: ${lastPrediction.ml_prediction.target_price > lastPrediction.technical_indicators.bollinger_bands.upper ? 
                            'Above Upper Band (Overbought)' :
                            lastPrediction.ml_prediction.target_price < lastPrediction.technical_indicators.bollinger_bands.lower ? 
                            'Below Lower Band (Oversold)' : 'Within Bands'}`;

      } else if (queryLower.includes('confidence') || queryLower.includes('accuracy')) {
        response = `Prediction Confidence and Accuracy for ${lastPrediction.ticker}:
        
1. Model Confidence:
   - Direction: ${lastPrediction.ml_prediction.direction.toUpperCase()}
   - Confidence Level: ${(lastPrediction.ml_prediction.confidence * 100).toFixed(1)}%
   - Expected Price: $${lastPrediction.ml_prediction.target_price.toFixed(2)}
   - Expected Date: ${new Date(lastPrediction.ml_prediction.predicted_date).toLocaleDateString()}

2. Backtesting Results:
   - Accuracy: ${lastPrediction.backtest_results.statistics.accuracy_percentage.toFixed(1)}%
   - Mean Absolute Error: $${lastPrediction.backtest_results.statistics.mean_absolute_error.toFixed(2)}
   - Root Mean Square Error: $${lastPrediction.backtest_results.statistics.rmse_price.toFixed(2)}

3. Model Performance:
   - Training Time: ${lastPrediction.training_info.training_time.toFixed(2)}s
   - Final Loss: ${lastPrediction.training_info.final_loss.toFixed(4)}
   - Model Type: ${lastPrediction.training_info.model_type}`;

      } else if (queryLower.includes('price') || queryLower.includes('target')) {
        response = `Price Analysis for ${lastPrediction.ticker}:
        
1. Current Analysis:
   - Predicted Direction: ${lastPrediction.ml_prediction.direction.toUpperCase()}
   - Target Price: $${lastPrediction.ml_prediction.target_price.toFixed(2)}
   - Expected Move: ${(lastPrediction.ml_prediction.predicted_move * 100).toFixed(1)}%
   - Timeframe: ${new Date(lastPrediction.ml_prediction.predicted_date).toLocaleDateString()}

2. Technical Context:
   - RSI: ${lastPrediction.technical_indicators.rsi.toFixed(2)}
   - MACD: ${lastPrediction.technical_indicators.macd.toFixed(2)}
   - Bollinger Bands: $${lastPrediction.technical_indicators.bollinger_bands.middle.toFixed(2)}

3. Model Confidence:
   - Confidence Level: ${(lastPrediction.ml_prediction.confidence * 100).toFixed(1)}%
   - Backtesting Accuracy: ${lastPrediction.backtest_results.statistics.accuracy_percentage.toFixed(1)}%`;

      } else if (queryLower.includes('backtest') || queryLower.includes('historical')) {
        response = `Backtesting Results for ${lastPrediction.ticker}:
        
1. Performance Metrics:
   - Accuracy: ${lastPrediction.backtest_results.statistics.accuracy_percentage.toFixed(1)}%
   - Mean Absolute Error: $${lastPrediction.backtest_results.statistics.mean_absolute_error.toFixed(2)}
   - Root Mean Square Error: $${lastPrediction.backtest_results.statistics.rmse_price.toFixed(2)}

2. Historical Performance:
   - Number of Predictions: ${lastPrediction.backtest_results.predictions.length}
   - Average Error: $${(lastPrediction.backtest_results.statistics.mean_absolute_error).toFixed(2)}
   - Model Type: ${lastPrediction.training_info.model_type}

3. Training Details:
   - Training Time: ${lastPrediction.training_info.training_time.toFixed(2)}s
   - Final Loss: ${lastPrediction.training_info.final_loss.toFixed(4)}`;

      } else {
        response = `I can help you understand the analysis of ${lastPrediction.ticker}. Please ask about:
        
- Technical indicators (RSI, MACD, Bollinger Bands)
- Prediction confidence and accuracy
- Price targets and expected moves
- Backtesting results and historical performance

Or ask any specific question about the analysis!`;
      }

      // Add assistant response
      setMessages(prev => [...prev, {
        type: 'assistant',
        content: response,
        timestamp: new Date()
      }]);

    } catch (error) {
      console.error('Query processing error:', error);
      setMessages(prev => [...prev, {
        type: 'assistant',
        content: 'Sorry, I encountered an error processing your question. Please try again.',
        timestamp: new Date()
      }]);
    }
  };

  const handlePrediction = async (ticker: string) => {
    try {
      setLoading(true);
      setProgress(0);
      setTimeRemaining(45);
      setLoadingStage(0);
      
      // Add user message
      const userMessage: Message = {
        type: 'user',
        content: `Analyze ${ticker}`,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, userMessage]);

      // Add initial loading message
      const loadingMessage: Message = {
        type: 'loading',
        content: 'Initializing analysis...',
        timestamp: new Date(),
        loadingStage: 0,
        progress: 0,
        timeRemaining: 45
      };
      setMessages(prev => [...prev, loadingMessage]);

      // Get auth token
      const token = localStorage.getItem('authToken');
      if (!token) {
        throw new Error('Authentication required. Please log in.');
      }

      // Cancel any existing request
      if (cancelTokenRef.current) {
        cancelTokenRef.current.cancel('Operation cancelled by new request');
      }
      cancelTokenRef.current = axios.CancelToken.source();

      // Create EventSource for streaming updates
      const eventSource = new EventSource(`http://localhost:8080/api/info`, {
        withCredentials: true
      });

      eventSource.onmessage = async (event) => {
        try {
          const data = JSON.parse(event.data);
          
          if (data.error) {
            throw new Error(data.error);
          }

          if (data.status === 'processing') {
            // Update progress
            setProgress(data.progress || 0);
            setLoadingStage(prev => prev + 1);
            setTimeRemaining(data.stage === 'complete' ? 0 : 45);

            // Update loading message
            setMessages(prev => {
              const newMessages = [...prev];
              const loadingMessageIndex = newMessages.findIndex(m => m.type === 'loading');
              if (loadingMessageIndex !== -1) {
                newMessages[loadingMessageIndex] = {
                  ...newMessages[loadingMessageIndex],
                  content: data.message || 'Processing...',
                  loadingStage: prev[loadingMessageIndex].loadingStage! + 1,
                  progress: data.progress || 0,
                  timeRemaining: data.stage === 'complete' ? 0 : 45
                };
              }
              return newMessages;
            });

            // Add GPU info if available
            if (data.gpu_info) {
              setMessages(prev => [...prev, {
                type: 'terminal',
                content: [
                  `[INFO] GPU Status: ${data.gpu_info.cuda_available ? 'Available' : 'Not Available'}`,
                  data.gpu_info.gpu_name ? `[INFO] Using GPU: ${data.gpu_info.gpu_name}` : '[INFO] Using CPU',
                ],
                timestamp: new Date()
              }]);
            }
          }

          if (data.status === 'completed') {
            // Remove loading message
            setMessages(prev => prev.filter(m => m.type !== 'loading'));

            // Validate and process the prediction result
            const predictionResult: PredictionResult = {
              ticker,
              training_info: {
                training_time: data.training_info?.training_time || 0,
                final_loss: data.training_info?.final_loss || 0,
                model_type: data.training_info?.model_type || 'Ensemble (LSTM + XGBoost)'
              },
              ml_prediction: {
                direction: data.ml_prediction?.direction || 'neutral',
                confidence: data.ml_prediction?.confidence || 0,
                target_price: data.ml_prediction?.target_price || 0,
                predicted_move: data.ml_prediction?.predicted_move || 0,
                predicted_date: data.ml_prediction?.predicted_date || new Date().toISOString()
              },
              backtest_results: {
                statistics: {
                  accuracy_percentage: data.backtest_results?.statistics?.accuracy_percentage || 0,
                  mean_absolute_error: data.backtest_results?.statistics?.mae || 0,
                  rmse_price: data.backtest_results?.statistics?.rmse || 0
                },
                predictions: data.backtest_results?.predictions || [],
                actuals: data.backtest_results?.actuals || []
              },
              technical_indicators: {
                rsi: data.technical_indicators?.rsi || 0,
                macd: data.technical_indicators?.macd || 0,
                signal: data.technical_indicators?.signal || 0,
                bollinger_bands: {
                  upper: data.technical_indicators?.bollinger_bands?.upper || 0,
                  middle: data.technical_indicators?.bollinger_bands?.middle || 0,
                  lower: data.technical_indicators?.bollinger_bands?.lower || 0
                }
              }
            };

            // Add visualization if available
            if (data.visualization) {
              setMessages(prev => [...prev, {
                type: 'chart',
                content: 'Price Prediction vs Actual',
                timestamp: new Date(),
                chartUrl: `data:image/png;base64,${data.visualization}`
              }]);
            }

            // Add prediction message with technical indicators
            setMessages(prev => [...prev, {
              type: 'prediction',
              content: `Analysis complete for ${ticker}`,
              timestamp: new Date(),
              prediction: predictionResult,
              indicators: [
                {
                  name: 'RSI',
                  value: predictionResult.technical_indicators.rsi.toFixed(2),
                  trend: predictionResult.technical_indicators.rsi > 70 ? 'down' : 
                         predictionResult.technical_indicators.rsi < 30 ? 'up' : 'neutral'
                },
                {
                  name: 'MACD',
                  value: predictionResult.technical_indicators.macd.toFixed(2),
                  trend: predictionResult.technical_indicators.macd > predictionResult.technical_indicators.signal ? 'up' : 'down'
                },
                {
                  name: 'Bollinger Bands',
                  value: predictionResult.technical_indicators.bollinger_bands.middle.toFixed(2),
                  trend: predictionResult.ml_prediction.target_price > predictionResult.technical_indicators.bollinger_bands.upper ? 'up' :
                         predictionResult.ml_prediction.target_price < predictionResult.technical_indicators.bollinger_bands.lower ? 'down' : 'neutral'
                }
              ]
            }]);

            // Close the event source
            eventSource.close();
            setLoading(false);
          }
        } catch (error) {
          console.error('Error processing server message:', error);
          eventSource.close();
          handlePredictionError(error, ticker);
        }
      };

      eventSource.onerror = (error) => {
        console.error('EventSource error:', error);
        eventSource.close();
        handlePredictionError(error, ticker);
      };

    } catch (error: any) {
      handlePredictionError(error, ticker);
    }
  };

  const handlePredictionError = (error: any, ticker: string) => {
    console.error('Prediction error:', error);
    
    // Remove loading message
    setMessages(prev => prev.filter(m => m.type !== 'loading'));

    // Add error message with better error handling
    let errorMessage = 'An error occurred during analysis';
    
    if (error.response?.data?.error) {
      errorMessage = error.response.data.error;
      if (error.response.status === 401) {
        navigate('/login', { state: { from: '/prediction' } });
        return;
      }
    } else if (error.response?.data?.message) {
      errorMessage = error.response.data.message;
    } else if (error.message) {
      errorMessage = error.message;
    } else if (axios.isCancel(error)) {
      errorMessage = 'Analysis was cancelled';
    }

    setMessages(prev => [...prev, {
      type: 'assistant',
      content: `Error analyzing ${ticker}: ${errorMessage}\n\nPlease try again or contact support if the issue persists.`,
      timestamp: new Date()
    }]);

    setLoading(false);
    setLoadingStage(0);
    setProgress(0);
    cancelTokenRef.current = null;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userInput = input.trim();
    setInput('');

    // Check if input is a ticker symbol
    const tickerRegex = /^[A-Za-z]{1,5}$/;
    const isTickerCommand = /^(?:analyze|predict|check)\s+([A-Za-z]{1,5})$/i;
    const tickerMatch = userInput.match(isTickerCommand);

    if (tickerRegex.test(userInput)) {
      await handlePrediction(userInput.toUpperCase());
    } else if (tickerMatch) {
      await handlePrediction(tickerMatch[1].toUpperCase());
    } else {
      await handleQuery(userInput);
    }
  };

  return (
    <div className="min-h-screen bg-black relative overflow-hidden flex flex-col">
      {/* Background effects */}
      <div className="fixed inset-0 overflow-hidden">
        {[...Array(40)].map((_, i) => (
          <div
            key={i}
            className="absolute bg-gradient-to-r from-transparent via-purple-500/10 to-transparent"
            style={{
              width: '300%',
              height: '2px',
              left: '-100%',
              top: `${Math.random() * 100}%`,
              transform: 'rotate(35deg)',
              animation: `floatLine ${20 + Math.random() * 15}s linear infinite`,
              animationDelay: `${-Math.random() * 10}s`,
              opacity: 0.2
            }}
          />
        ))}
      </div>

      {/* Holographic scan lines */}
      <div className="fixed inset-0 pointer-events-none">
        {[...Array(50)].map((_, i) => (
          <div
            key={i}
            className="absolute w-full h-px bg-gradient-to-r from-transparent via-purple-400/5 to-transparent"
            style={{
              top: `${i * 2}%`,
              animation: `scanLine 8s linear infinite ${i * 0.1}s`,
              opacity: 0.2
            }}
          />
        ))}
      </div>

      {/* Glowing background */}
      <div className="absolute w-[120vh] h-[120vh] rounded-full bg-purple-900/5 animate-pulse-slow blur-xl" />
      <div className="absolute w-[100vh] h-[100vh] rounded-full bg-blue-800/5 animate-pulse-slow delay-75 blur-lg" />

      {/* Main content container */}
      <div className="flex-1 flex flex-col max-w-6xl mx-auto w-full p-4 gap-4 relative z-10">
        {/* Header */}
        <div className="bg-gray-900/50 backdrop-blur-sm border border-gray-800/50 rounded-lg p-4">
          <h1 className="text-2xl font-bold text-white mb-2">VECAID AI Prediction</h1>
          <p className="text-gray-400">
            Welcome{user?.email ? `, ${user.email}! ` : '! '}
            Enter a stock ticker or ask questions about previous predictions
          </p>
        </div>

        {/* Chat container */}
        <div className="flex-1 flex flex-col min-h-0 bg-gray-900/50 backdrop-blur-sm border border-gray-800/50 rounded-lg">
          {/* Messages container */}
          <div 
            className="flex-1 overflow-y-auto p-4 space-y-4" 
            ref={chatContainerRef}
            style={{ maxHeight: 'calc(100vh - 300px)' }}
          >
            <AnimatePresence>
              {messages.map((message, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className={`${message.type === 'user' ? 'ml-auto' : 'mr-auto'} max-w-3xl`}
                >
                  <div className={`rounded-lg p-4 ${
                    message.type === 'user'
                      ? 'bg-purple-600/20 border border-purple-500/30 ml-auto'
                      : 'bg-gray-800/50 border border-gray-700/50'
                  }`}>
                    {message.type === 'loading' && (
                      <div className="text-gray-400 mb-2">
                        <div className="mb-2">
                          Stage {loadingStage + 1}/{loadingMessages.length}: {loadingMessages[loadingStage]}
                        </div>
                        <div className="w-full h-2 bg-gray-700 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-purple-600 transition-all duration-300 ease-in-out"
                            style={{ width: `${progress}%` }}
                          />
                        </div>
                        <div className="text-sm mt-1 text-gray-500">
                          {formatTimeRemaining(timeRemaining)}
                        </div>
                      </div>
                    )}
                    {message.type === 'chart' && message.chartUrl && (
                      <div className="mb-2">
                        <img src={message.chartUrl} alt="Chart" className="rounded-lg w-full" />
                      </div>
                    )}
                    {message.type === 'terminal' && Array.isArray(message.content) && (
                      <div className="space-y-1">
                        {message.content.map((line, idx) => renderTerminalLine(line, idx))}
                      </div>
                    )}
                    {message.type !== 'terminal' && (
                      <div className="text-white whitespace-pre-wrap">
                        {message.content}
                      </div>
                    )}
                    {message.indicators && (
                      <div className="grid grid-cols-2 gap-4 mt-4">
                        {message.indicators.map((indicator, i) => (
                          <div key={i} className="bg-gray-900/50 p-3 rounded-lg">
                            <div className="text-gray-400 text-sm">{indicator.name}</div>
                            <div className="text-white font-bold flex items-center gap-2">
                              {indicator.value}
                              <span className={`${
                                indicator.trend === 'up' ? 'text-green-500' :
                                indicator.trend === 'down' ? 'text-red-500' :
                                'text-gray-500'
                              }`}>
                                {indicator.trend === 'up' ? '↑' : indicator.trend === 'down' ? '↓' : '→'}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                    <div className="text-xs text-gray-500 mt-2">
                      {message.timestamp.toLocaleTimeString()}
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
            <div ref={messagesEndRef} />
          </div>

          {/* Input form */}
          <div className="p-4 border-t border-gray-800/50">
            <form onSubmit={handleSubmit} className="relative">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={loading ? "Processing..." : "Enter a ticker symbol or ask me anything..."}
                className="w-full bg-gray-900/50 border border-gray-800/50 rounded-lg py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent backdrop-blur-sm"
                disabled={loading}
              />
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                type="submit"
                disabled={loading || !input.trim()}
                className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-purple-600 text-white px-4 py-1 rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                ) : (
                  'Send'
                )}
              </motion.button>
              {loading && (
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={handleCancel}
                  className="absolute right-24 top-1/2 transform -translate-y-1/2 bg-red-600 text-white px-4 py-1 rounded-lg hover:bg-red-700"
                >
                  Cancel
                </motion.button>
              )}
            </form>
          </div>
        </div>
      </div>

      {/* Chat History Slide-out Panel */}
      <motion.div
        initial={{ x: '-100%' }}
        animate={{ x: isHistoryOpen ? '0%' : '-100%' }}
        transition={{ type: 'spring', stiffness: 300, damping: 30 }}
        className="fixed left-0 top-0 bottom-0 w-80 bg-gray-900/95 border-r border-gray-800/50 backdrop-blur-lg z-20"
      >
        <div className="p-4">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-display text-white">Chat History</h2>
            <button
              onClick={() => setIsHistoryOpen(false)}
              className="text-gray-400 hover:text-white transition-colors"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          
          <select
            value={selectedDate}
            onChange={(e) => loadChatHistory(e.target.value)}
            className="w-full bg-gray-800 text-white border border-gray-700 rounded-lg p-2 mb-4"
          >
            <option value="">Select a date</option>
            {Object.keys(messagesByDate).map(date => (
              <option key={date} value={date}>
                {date} ({messagesByDate[date].length} messages)
              </option>
            ))}
          </select>

          <div className="space-y-4 max-h-[calc(100vh-8rem)] overflow-y-auto">
            {selectedDate && messagesByDate[selectedDate].map((message, index) => (
              <div
                key={index}
                className="p-3 rounded-lg bg-gray-800/50 border border-gray-700/50"
              >
                <div className="text-sm text-gray-400">
                  {message.type === 'user' ? 'You' : 'VECAID'}
                </div>
                <div className="text-white text-sm mt-1">
                  {typeof message.content === 'string' 
                    ? message.content.length > 50 
                      ? message.content.substring(0, 50) + '...' 
                      : message.content
                    : 'Multiple lines...'}
                </div>
                <div className="text-xs text-gray-500 mt-2">
                  {message.timestamp.toLocaleTimeString()}
                </div>
              </div>
            ))}
          </div>
        </div>
      </motion.div>

      <style>{`
        @keyframes shimmer {
          0% {
            transform: translateX(-100%);
          }
          100% {
            transform: translateX(100%);
          }
        }
        
        .animate-shimmer {
          animation: shimmer 2s infinite;
        }
        
        .animate-pulse-slow {
          animation: pulse 3s infinite;
        }

        .terminal-text {
          text-shadow: 0 0 1px rgba(255, 255, 255, 0.1);
        }

        .vecaid-text {
          position: relative;
          text-shadow: 
            0 0 2px rgba(168, 85, 247, 0.2),
            0 0 4px rgba(168, 85, 247, 0.1);
          background: linear-gradient(
            90deg,
            rgba(168, 85, 247, 0) 0%,
            rgba(168, 85, 247, 0.1) 25%,
            rgba(168, 85, 247, 0.1) 75%,
            rgba(168, 85, 247, 0) 100%
          );
          border-radius: 4px;
          padding: 0 4px;
          margin: 0 -4px;
        }

        /* Improved scrollbar styling */
        .overflow-y-auto {
          scrollbar-width: thin;
          scrollbar-color: rgba(139, 92, 246, 0.3) rgba(17, 24, 39, 0.2);
        }

        .overflow-y-auto::-webkit-scrollbar {
          width: 6px;
        }

        .overflow-y-auto::-webkit-scrollbar-track {
          background: rgba(17, 24, 39, 0.2);
          border-radius: 3px;
        }

        .overflow-y-auto::-webkit-scrollbar-thumb {
          background-color: rgba(139, 92, 246, 0.3);
          border-radius: 3px;
          transition: background-color 0.2s;
        }

        .overflow-y-auto::-webkit-scrollbar-thumb:hover {
          background-color: rgba(139, 92, 246, 0.5);
        }
      `}</style>
    </div>
  );
};

export default PredictionPage; 