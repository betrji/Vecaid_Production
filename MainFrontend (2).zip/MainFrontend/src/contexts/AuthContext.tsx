import React, { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export interface User {
  email: string;
  isSubscribed: boolean;
  isDeveloper: boolean;
  directAccess?: boolean;
}

export interface AuthContextType {
  user: User | null;
  loading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  signup: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  isAuthenticated: boolean;
  isSubscribed: boolean;
  isDeveloper: boolean;
  developerAuth: (key: string) => Promise<void>;
  handleSubscribe: () => Promise<void>;
  clearError: () => void;
  setUser: (user: User | null) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Create axios instance with base URL
const api = axios.create({
  baseURL: 'http://localhost:8080',
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true,
});

// Add request interceptor to add token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const token = localStorage.getItem('authToken');
      if (!token) {
        setLoading(false);
        return;
      }

      const response = await api.get('/api/auth/check');
      setUser(response.data.user);
      
      // If user has direct access, redirect to prediction page
      if (response.data.user.directAccess) {
        navigate('/prediction');
      }
    } catch (err) {
      localStorage.removeItem('authToken');
    } finally {
      setLoading(false);
    }
  };

  const login = async (email: string, password: string) => {
    try {
      setError(null);
      setLoading(true);
      const response = await api.post('/api/auth/login', { email, password });
      localStorage.setItem('authToken', response.data.token);
      setUser(response.data.user);
      navigate('/prediction');
    } catch (err: any) {
      setError(err.response?.data?.error || 'An error occurred during login');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const signup = async (email: string, password: string) => {
    try {
      setError(null);
      setLoading(true);
      const response = await api.post('/api/auth/signup', { email, password });
      localStorage.setItem('authToken', response.data.token);
      setUser(response.data.user);
      navigate('/login');
    } catch (err: any) {
      setError(err.response?.data?.error || 'An error occurred during signup');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const developerAuth = async (key: string) => {
    try {
      setError(null);
      const response = await api.post('/api/auth/developer', { key });
      localStorage.setItem('authToken', response.data.token);
      setUser(response.data.user);
      
      // Directly navigate to prediction page for developer access
      if (response.data.redirect) {
        navigate(response.data.redirect);
      }
    } catch (err: any) {
      setError(err.response?.data?.error || 'Invalid developer key');
      throw err;
    }
  };

  const logout = async () => {
    try {
      await api.post('/api/auth/logout');
      localStorage.removeItem('authToken');
      setUser(null);
      navigate('/login');
    } catch (err: any) {
      setError(err.response?.data?.error || 'An error occurred during logout');
      throw err;
    }
  };

  const handleSubscribe = async () => {
    try {
      setLoading(true);
      const response = await api.post('/api/subscription/create-checkout');
      if (response.data.url) {
        window.location.href = response.data.url;
      }
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to initiate subscription');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const clearError = () => {
    setError(null);
  };

  const isAuthenticated = !!user;
  const isSubscribed = !!user && user.isSubscribed;
  const isDeveloper = !!user && user.isDeveloper;

  const value = {
    user,
    loading,
    error,
    login,
    signup,
    logout,
    isAuthenticated,
    isSubscribed,
    isDeveloper,
    developerAuth,
    handleSubscribe,
    clearError,
    setUser,
  };

  return (
    <AuthContext.Provider
      value={value}
    >
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContext; 