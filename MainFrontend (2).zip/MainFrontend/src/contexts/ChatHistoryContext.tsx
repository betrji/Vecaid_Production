import React, { createContext, useContext, useState, ReactNode } from 'react';

interface ChatHistoryContextType {
  isHistoryOpen: boolean;
  setIsHistoryOpen: (isOpen: boolean) => void;
}

const ChatHistoryContext = createContext<ChatHistoryContextType | undefined>(undefined);

export function ChatHistoryProvider({ children }: { children: ReactNode }) {
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);

  return (
    <ChatHistoryContext.Provider value={{ isHistoryOpen, setIsHistoryOpen }}>
      {children}
    </ChatHistoryContext.Provider>
  );
}

export function useChatHistory() {
  const context = useContext(ChatHistoryContext);
  if (context === undefined) {
    throw new Error('useChatHistory must be used within a ChatHistoryProvider');
  }
  return context;
} 