import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8080';
const WS_URL = import.meta.env.VITE_WS_URL || 'ws://localhost:8080';
const API_TIMEOUT = parseInt(import.meta.env.VITE_API_TIMEOUT || '30000', 10);

// Create axios instance with default config
export const api = axios.create({
    baseURL: API_URL,
    timeout: API_TIMEOUT,
    headers: {
        'Content-Type': 'application/json',
    },
    withCredentials: true
});

// Add request interceptor to add auth token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Add response interceptor to handle errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('authToken');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// API endpoints
export const endpoints = {
    auth: {
        login: '/api/auth/login',
        signup: '/api/auth/signup',
        check: '/api/auth/check',
        logout: '/api/auth/logout',
        developer: '/api/auth/developer'
    },
    predictions: {
        info: '/api/info',
        cancel: (ticker: string) => `/api/info/cancel/${ticker}`,
        status: (ticker: string) => `/api/info/status/${ticker}`
    }
};

export const getWebSocketUrl = () => WS_URL;

export { API_URL };

export default api; 