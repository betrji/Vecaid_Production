import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import os
import json
from datetime import datetime, UTC
import logging
from typing import List, Dict, Any, Optional, Tuple
import time
from tqdm import tqdm
from flask import Flask, request, jsonify, send_from_directory, session as flask_session, make_response, Response, stream_with_context
from flask_cors import CORS, cross_origin
from flask_socketio import SocketIO, emit, join_room, leave_room
import yfinance as yf
from concurrent.futures import ThreadPoolExecutor
import threading
import queue
import jwt
from werkzeug.security import generate_password_hash, check_password_hash
import stripe
from dateutil.relativedelta import relativedelta
from dotenv import load_dotenv
import pickle
from sklearn.metrics import mean_squared_error
import xgboost as xgb

def main():
    try:
        logger.info("Initializing VECAID Backend...")
    
        # Initialize SocketIO with CORS support
        socketio = SocketIO(app, cors_allowed_origins="*")
        
        # WebSocket event handlers
        @socketio.on('connect')
        def handle_connect():
            logger.info(f"Client connected: {request.sid}")
        
        @socketio.on('disconnect')
        def handle_disconnect():
            logger.info(f"Client disconnected: {request.sid}")
            # Remove client from active subscriptions
            if request.sid in active_socket_clients:
                ticker = active_socket_clients[request.sid]
                leave_room(ticker)
                del active_socket_clients[request.sid]
        
        @socketio.on('subscribe')
        def handle_subscribe(data):
            ticker = data.get('ticker')
            if ticker:
                join_room(ticker)
                active_socket_clients[request.sid] = ticker
                logger.info(f"Client {request.sid} subscribed to {ticker} updates")
        
        @socketio.on('prediction_request')
        def handle_prediction_request(data):
            try:
                ticker = data.get('ticker')
                if ticker:
                    # Emit initial status
                    emit('prediction_status', {
                        'ticker': ticker,
                        'status': 'started',
                        'message': f'Starting prediction for {ticker}'
                    })
                    
                    # Start prediction process in PredictionTask
                    with prediction_lock:
                        if ticker not in active_predictions:
                            task = PredictionTask(ticker)
                            active_predictions[ticker] = task
                            task.start()
                        else:
                            emit('prediction_error', {
                                'ticker': ticker,
                                'error': 'Prediction already in progress'
                            })
                            
            except Exception as e:
                logger.error(f"Error in prediction request: {str(e)}")
                emit('prediction_error', {'error': str(e)})
        
        # Start Flask-SocketIO server
        logger.info("Starting Flask-SocketIO server on port 8080...")
        socketio.run(app, host='0.0.0.0', port=8080, debug=True)
        
    except Exception as e:
        logger.error(f"Critical error in main: {str(e)}")
        raise

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

# Initialize global variables and configuration
DEVELOPER_KEY = "47906"  # Replace with your actual developer key
JWT_SECRET_KEY = "ureallythoughtyouwereabouttogetthissecretkeyyoudumbidiot"  # Replace with your actual JWT secret key

# Stripe Configuration
STRIPE_CONFIG = {
    'api_key': 'sk_test_51R9A09Pjg9aJM7FIgCBeiJJWLhiLs7Z835fEid4JS8NusmxN3ltePtzLVea4jsRqFcHjqFFRZtEt1PR0a1b4edpR00htboUeNS',
    'success_url': 'http://localhost:5173/subscription/success',
    'cancel_url': 'http://localhost:5173/subscription'
}

# Configure allowed origins
ALLOWED_ORIGINS = ["http://localhost:5173", "http://127.0.0.1:5173"]

# Model configuration
MODEL_SAVE_PATH = 'models'
SCALER_SAVE_PATH = 'scalers'
SEQUENCE_LENGTH = 60
PREDICTION_HORIZON = 5

# Initialize other global variables
active_predictions = {}
prediction_lock = threading.Lock()
training_lock = threading.Lock()
executor = ThreadPoolExecutor(max_workers=4)
predictor = None

# Mock user database (replace with real database in production)
users_db = {
    "developer@vecaid.ai": {
        "password": generate_password_hash("devpass"),
        "is_subscribed": True,
        "stripe_customer_id": None,
        "stripe_subscription_id": None
    }
}

# Check for GPU availability and set up device
cuda_info = {
    'cuda_available': torch.cuda.is_available(),
    'cuda_version': torch.version.cuda if torch.cuda.is_available() else None,
    'gpu_name': torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
    'gpu_count': torch.cuda.device_count() if torch.cuda.is_available() else 0,
    'current_device': torch.cuda.current_device() if torch.cuda.is_available() else None
}

if cuda_info['cuda_available']:
    device = torch.device('cuda')
    torch.backends.cudnn.benchmark = True
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True
    logger.info(f"=== CUDA Information ===")
    logger.info(f"CUDA available: {cuda_info['cuda_available']}")
    logger.info(f"Using GPU: {cuda_info['gpu_name']}")
    logger.info(f"CUDA Version: {cuda_info['cuda_version']}")
    logger.info(f"GPU Count: {cuda_info['gpu_count']}")
    logger.info(f"Current Device: {cuda_info['current_device']}")
else:
    device = torch.device('cpu')
    logger.info("Using CPU - CUDA not available")

# Initialize Flask app
app = Flask(__name__)
app.secret_key = JWT_SECRET_KEY

# Configure CORS with proper resource configuration
CORS(app, resources={
    r"/api/*": {
        "origins": ["http://localhost:5173", "http://127.0.0.1:5173", "http://localhost:8080", "http://127.0.0.1:8080"],
        "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        "allow_headers": ["Content-Type", "Authorization", "X-Requested-With"],
        "supports_credentials": True,
        "expose_headers": ["Content-Type", "Authorization"],
        "max_age": 3600
    }
})

@app.after_request
def after_request(response):
    origin = request.headers.get('Origin')
    allowed_origins = ["http://localhost:5173", "http://127.0.0.1:5173", "http://localhost:8080", "http://127.0.0.1:8080"]
    if origin in allowed_origins:
        response.headers.update({
            'Access-Control-Allow-Origin': origin,
            'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With',
            'Access-Control-Allow-Credentials': 'true',
            'Access-Control-Max-Age': '3600',
            'Access-Control-Expose-Headers': 'Content-Type, Authorization'
        })
    return response

@app.route('/')
def serve_root():
    return jsonify({
        'message': 'VECAID Backend API',
        'status': 'running',
        'endpoints': {
            'api': '/api',
            'predictions': '/api/info'
        }
    })

@app.route('/api')
@cross_origin(supports_credentials=True)
def api_root():
    try:
        return jsonify({
            'message': 'VECAID Backend is running',
            'status': 'active',
            'version': '1.0.0',
            'gpu_info': cuda_info,
            'timestamp': datetime.now(UTC).isoformat()
        })
    except Exception as e:
        logger.error(f"Error in root endpoint: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/info', methods=['GET'])
@cross_origin(supports_credentials=True)
def info_status():
    """Root endpoint for info API to handle direct GET requests"""
    try:
        return jsonify({
            'message': 'VECAID Prediction API is running',
            'status': 'active',
            'endpoints': {
                'prediction': '/api/info (POST)',
                'cancel': '/api/info/cancel/<ticker> (POST)',
                'status': '/api/info/status/<ticker> (GET)'
            },
            'gpu_info': cuda_info,
            'active_predictions': len(active_predictions),
            'timestamp': datetime.now(UTC).isoformat()
        })
    except Exception as e:
        logger.error(f"Error in info status endpoint: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/info', methods=['OPTIONS'])
@cross_origin(supports_credentials=True)
def info_options():
    response = make_response()
    response.headers.update({
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        'Access-Control-Max-Age': '3600'
    })
    return response

class TimeSeriesDataset(Dataset):
    def __init__(self, X: np.ndarray, y: np.ndarray):
        self.X = torch.FloatTensor(X)
        self.y = torch.FloatTensor(y)
        
    def __len__(self) -> int:
        return len(self.X)
    
    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        return self.X[idx], self.y[idx]

class LSTMModel(nn.Module):
    def __init__(self, input_size: int, hidden_size: int, num_layers: int, output_size: int, dropout: float = 0.2):
        super(LSTMModel, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        
        # LSTM layer
        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0
        )
        
        # Dropout layer
        self.dropout = nn.Dropout(dropout)
        
        # Fully connected layer
        self.fc = nn.Linear(hidden_size, output_size)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Initialize hidden state with zeros
        batch_size = x.size(0)
        h0 = torch.zeros(self.num_layers, batch_size, self.hidden_size).to(x.device)
        c0 = torch.zeros(self.num_layers, batch_size, self.hidden_size).to(x.device)
        
        # Forward propagate LSTM
        out, _ = self.lstm(x, (h0, c0))
        
        # Decode the hidden state of the last time step
        out = self.dropout(out[:, -1, :])
        out = self.fc(out)
        
        return out

class TimeSeriesPredictor:
    def __init__(self, model_path: str = MODEL_SAVE_PATH, scaler_path: str = SCALER_SAVE_PATH):
        self.model_path = model_path
        self.scaler_path = scaler_path
        self.models: Dict[str, Any] = {}  # Store both PyTorch and XGBoost models
        self.scalers: Dict[str, MinMaxScaler] = {}
        self.sequence_length = SEQUENCE_LENGTH
        self.prediction_horizon = PREDICTION_HORIZON
        self.batch_size = int(os.getenv('BATCH_SIZE', '32'))
        self.epochs = int(os.getenv('EPOCHS', '50'))
        self.learning_rate = float(os.getenv('LEARNING_RATE', '0.001'))
        self.patience = int(os.getenv('PATIENCE', '10'))
        
        # Ensure directories exist
        os.makedirs(model_path, exist_ok=True)
        os.makedirs(scaler_path, exist_ok=True)
        
        # Load existing models and scalers
        self._load_existing_models()
        
    def _load_existing_models(self):
        """Load existing models and scalers from disk"""
        try:
            # Load scalers
            for file in os.listdir(self.scaler_path):
                if file.endswith('.pkl'):
                    ticker = file.replace('_scaler.pkl', '')
                    with open(os.path.join(self.scaler_path, file), 'rb') as f:
                        self.scalers[ticker] = pickle.load(f)
            
            # Load models
            for file in os.listdir(self.model_path):
                if file.endswith('_lstm.pth'):
                    ticker = file.replace('_lstm.pth', '')
                    if ticker not in self.models:
                        self.models[ticker] = {}
                    self.models[ticker]['lstm'] = torch.load(os.path.join(self.model_path, file))
                elif file.endswith('_xgb.pkl'):
                    ticker = file.replace('_xgb.pkl', '')
                    if ticker not in self.models:
                        self.models[ticker] = {}
                    with open(os.path.join(self.model_path, file), 'rb') as f:
                        self.models[ticker]['xgb'] = pickle.load(f)
            
            logger.info(f"Loaded {len(self.models)} models and {len(self.scalers)} scalers from disk")
        except Exception as e:
            logger.error(f"Error loading existing models: {str(e)}")
    
    def _save_model(self, ticker: str, model_type: str, model: Any):
        """Save a model to disk"""
        try:
            if model_type == 'lstm':
                torch.save(model.state_dict(), os.path.join(self.model_path, f"{ticker}_lstm.pth"))
            elif model_type == 'xgb':
                with open(os.path.join(self.model_path, f"{ticker}_xgb.pkl"), 'wb') as f:
                    pickle.dump(model, f)
            logger.info(f"Saved {model_type} model for {ticker}")
        except Exception as e:
            logger.error(f"Error saving {model_type} model for {ticker}: {str(e)}")
    
    def _save_scaler(self, ticker: str, scaler: MinMaxScaler):
        """Save a scaler to disk"""
        try:
            with open(os.path.join(self.scaler_path, f"{ticker}_scaler.pkl"), 'wb') as f:
                pickle.dump(scaler, f)
            logger.info(f"Saved scaler for {ticker}")
        except Exception as e:
            logger.error(f"Error saving scaler for {ticker}: {str(e)}")

    def get_stock_data(self, ticker: str, period: str = "2y") -> pd.DataFrame:
        """Fetch real-time and historical stock data using yfinance"""
        try:
            stock = yf.Ticker(ticker)
            df = stock.history(period=period, interval="1d")
            if df.empty:
                raise ValueError(f"No data found for ticker {ticker}")
            return df
        except Exception as e:
            logger.error(f"Error fetching data for {ticker}: {str(e)}")
            raise

    def preprocess_data(self, data: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        """Preprocess data and create features"""
        # Technical indicators
        data['RSI'] = self.calculate_rsi(data['Close'])
        data['MACD'], data['Signal'] = self.calculate_macd(data['Close'])
        data['BB_upper'], data['BB_middle'], data['BB_lower'] = self.calculate_bollinger_bands(data['Close'])
        
        # Additional features
        data['Returns'] = data['Close'].pct_change()
        data['Volatility'] = data['Returns'].rolling(window=20).std()
        data['Volume_MA'] = data['Volume'].rolling(window=20).mean()
        
        # Drop NaN values
        data = data.dropna()
        
        # Create feature matrix
        features = np.column_stack((
            data['Close'].values,
            data['Volume'].values,
            data['RSI'].values,
            data['MACD'].values,
            data['BB_upper'].values,
            data['BB_lower'].values,
            data['Returns'].values,
            data['Volatility'].values,
            data['Volume_MA'].values
        ))
        
        return features, data['Close'].values

    def train_model(self, ticker: str, data: pd.DataFrame) -> Dict[str, Any]:
        """Train both LSTM and XGBoost models"""
        start_time = time.time()
        features, targets = self.preprocess_data(data)
        
        # Scale the data
        scaler = MinMaxScaler()
        features_scaled = scaler.fit_transform(features)
        self.scalers[ticker] = scaler
        self._save_scaler(ticker, scaler)
        
        # Create sequences
        X, y = self.create_sequences(features_scaled, self.sequence_length, self.prediction_horizon)
        
        # Split data
        train_size = int(len(X) * 0.8)
        X_train, X_val = X[:train_size], X[train_size:]
        y_train, y_val = y[:train_size], y[train_size:]
        
        # Train LSTM model
        lstm_model, best_val_loss = self.train_lstm(X_train, y_train, X_val, y_val, ticker)
        self._save_model(ticker, 'lstm', lstm_model)
        
        # Train XGBoost model
        xgb_model = self.train_xgboost(X_train.reshape(X_train.shape[0], -1), y_train,
                                      X_val.reshape(X_val.shape[0], -1), y_val)
        self._save_model(ticker, 'xgb', xgb_model)
        
        # Save models to dictionary
        self.models[ticker] = {
            'lstm': lstm_model,
            'xgb': xgb_model,
            'scaler': scaler
        }
        
        return {
            'training_time': time.time() - start_time,
            'final_loss': float(best_val_loss)
        }

    def train_lstm(self, X_train, y_train, X_val, y_val, ticker: str) -> Tuple[nn.Module, float]:
        """Train LSTM model with early stopping"""
        hidden_size = int(os.getenv('HIDDEN_SIZE', '128'))
        num_layers = int(os.getenv('NUM_LAYERS', '2'))
        dropout = float(os.getenv('DROPOUT', '0.2'))
        
        model = LSTMModel(
            input_size=X_train.shape[2],
            hidden_size=hidden_size,
            num_layers=num_layers,
            output_size=self.prediction_horizon,
            dropout=dropout
        ).to(device)
        
        criterion = nn.MSELoss()
        optimizer = optim.Adam(model.parameters(), lr=self.learning_rate)
        
        train_dataset = TimeSeriesDataset(X_train, y_train)
        val_dataset = TimeSeriesDataset(X_val, y_val)
        train_loader = DataLoader(train_dataset, batch_size=self.batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=self.batch_size)
        
        best_val_loss = float('inf')
        patience_counter = 0
        
        for epoch in range(self.epochs):
            model.train()
            train_loss = 0
            for X_batch, y_batch in train_loader:
                X_batch, y_batch = X_batch.to(device), y_batch.to(device)
                optimizer.zero_grad()
                outputs = model(X_batch)
                loss = criterion(outputs, y_batch)
                loss.backward()
                optimizer.step()
                train_loss += loss.item()
            
            # Validation
            model.eval()
            val_loss = 0
            with torch.no_grad():
                for X_batch, y_batch in val_loader:
                    X_batch, y_batch = X_batch.to(device), y_batch.to(device)
                    outputs = model(X_batch)
                    val_loss += criterion(outputs, y_batch).item()
            
            # Early stopping
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                patience_counter = 0
                self._save_model(ticker, 'lstm', model)
            else:
                patience_counter += 1
                if patience_counter >= self.patience:
                    break
        
        return model, best_val_loss

    def train_xgboost(self, X_train, y_train, X_val, y_val) -> Any:
        """Train XGBoost model"""
        import xgboost as xgb
        
        dtrain = xgb.DMatrix(X_train, label=y_train)
        dval = xgb.DMatrix(X_val, label=y_val)
        
        params = {
            'objective': 'reg:squarederror',
            'eval_metric': 'rmse',
            'max_depth': 6,
            'learning_rate': 0.1,
            'n_estimators': 1000,
            'subsample': 0.8,
            'colsample_bytree': 0.8
        }
        
        model = xgb.train(
            params,
            dtrain,
            num_boost_round=1000,
            evals=[(dtrain, 'train'), (dval, 'val')],
            early_stopping_rounds=50,
            verbose_eval=False
        )
        
        return model

    def backtest(self, ticker: str, data: pd.DataFrame) -> Dict[str, Any]:
        """Perform backtesting on historical data"""
        features, targets = self.preprocess_data(data)
        features_scaled = self.scalers[ticker].transform(features)
        
        predictions = []
        actuals = []
        
        # Create sequences for backtesting
        for i in range(len(features_scaled) - self.sequence_length - self.prediction_horizon):
            X = features_scaled[i:i+self.sequence_length].reshape(1, self.sequence_length, -1)
            y_true = targets[i+self.sequence_length:i+self.sequence_length+self.prediction_horizon]
            
            # Get predictions from both models
            lstm_pred = self.models[ticker]['lstm'](torch.FloatTensor(X).to(device)).cpu().detach().numpy()
            xgb_pred = self.models[ticker]['xgb'].predict(
                xgb.DMatrix(X.reshape(1, -1))
            ).reshape(-1, self.prediction_horizon)
            
            # Ensemble predictions (simple average)
            y_pred = (lstm_pred + xgb_pred) / 2
            
            predictions.append(y_pred[0])
            actuals.append(y_true)
        
        predictions = np.array(predictions)
        actuals = np.array(actuals)
        
        # Calculate metrics
        mse = mean_squared_error(actuals, predictions)
        rmse = np.sqrt(mse)
        mae = np.mean(np.abs(actuals - predictions))
        
        # Calculate directional accuracy
        direction_correct = np.sum(np.sign(predictions[1:] - predictions[:-1]) == 
                                 np.sign(actuals[1:] - actuals[:-1]))
        accuracy = direction_correct / (len(predictions) - 1)
        
        return {
            'statistics': {
                'mse': mse,
                'rmse': rmse,
                'mae': mae,
                'accuracy_percentage': accuracy * 100
            },
            'predictions': predictions.tolist(),
            'actuals': actuals.tolist()
        }

    def create_visualization(self, predictions: np.ndarray, actuals: np.ndarray, ticker: str) -> str:
        """Create visualization of predictions vs actuals"""
        try:
            import matplotlib.pyplot as plt
            import io
            import base64

            plt.figure(figsize=(12, 6))
            plt.plot(actuals, label='Actual Price', color='blue', alpha=0.7)
            plt.plot(predictions, label='Predicted Price', color='red', alpha=0.7)
            plt.title(f'{ticker} - Price Prediction vs Actual')
            plt.xlabel('Time')
            plt.ylabel('Price')
            plt.legend()
            plt.grid(True, alpha=0.3)

            # Save plot to base64 string
            buffer = io.BytesIO()
            plt.savefig(buffer, format='png', dpi=300, bbox_inches='tight')
            buffer.seek(0)
            image_base64 = base64.b64encode(buffer.getvalue()).decode()
            plt.close()

            return image_base64
        except Exception as e:
            logger.error(f"Error creating visualization: {str(e)}")
            return ""

    def predict(self, ticker: str) -> Dict[str, Any]:
        """Make predictions using both models and return comprehensive results"""
        try:
            # Get real-time data
            data = self.get_stock_data(ticker)
            
            # Train models if not already trained
            if ticker not in self.models:
                training_info = self.train_model(ticker, data)
            else:
                training_info = {'training_time': 0, 'final_loss': 0}
            
            # Calculate technical indicators
            technical_indicators = self.calculate_technical_indicators(data)
            
            # Prepare latest data for prediction
            features, _ = self.preprocess_data(data)
            features_scaled = self.scalers[ticker].transform(features)
            X = features_scaled[-self.sequence_length:].reshape(1, self.sequence_length, -1)
            X_tensor = torch.FloatTensor(X).to(device)
            
            # Get predictions from both models
            self.models[ticker]['lstm'].eval()  # Set model to evaluation mode
            with torch.no_grad():
                lstm_pred = self.models[ticker]['lstm'](X_tensor).cpu().numpy()
            
            xgb_pred = self.models[ticker]['xgb'].predict(
                xgb.DMatrix(X.reshape(1, -1))
            ).reshape(-1, self.prediction_horizon)
            
            # Ensemble predictions
            final_prediction = (lstm_pred + xgb_pred) / 2
            
            # Perform backtesting
            backtest_results = self.backtest(ticker, data)
            
            # Create visualization
            viz_data = self.create_visualization(
                backtest_results['predictions'],
                backtest_results['actuals'],
                ticker
            )
            
            # Determine prediction direction and confidence
            current_price = data['Close'].iloc[-1]
            predicted_price = final_prediction[0][0]
            price_change = predicted_price - current_price
            direction = 'up' if price_change > 0 else 'down'
            confidence = backtest_results['statistics']['accuracy_percentage'] / 100
            
            return {
                'ticker': ticker,
                'training_info': training_info,
                'ml_prediction': {
                    'direction': direction,
                    'confidence': confidence,
                    'target_price': float(predicted_price),
                    'predicted_move': float(price_change / current_price),
                    'predicted_date': (datetime.now(UTC) + relativedelta(days=1)).isoformat()
                },
                'backtest_results': backtest_results,
                'technical_indicators': technical_indicators,
                'visualization': viz_data
            }
            
        except Exception as e:
            logger.error(f"Error making prediction for {ticker}: {str(e)}")
            raise

    def calculate_technical_indicators(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Calculate technical indicators for the latest data point"""
        try:
            rsi = self.calculate_rsi(data['Close'])[-1]
            macd, signal = self.calculate_macd(data['Close'])
            bb_upper, bb_middle, bb_lower = self.calculate_bollinger_bands(data['Close'])
            
            return {
                'rsi': float(rsi),
                'macd': float(macd[-1]),
                'signal': float(signal[-1]),
                'bollinger_bands': {
                    'upper': float(bb_upper[-1]),
                    'middle': float(bb_middle[-1]),
                    'lower': float(bb_lower[-1])
                }
            }
        except Exception as e:
            logger.error(f"Error calculating technical indicators: {str(e)}")
            raise

    def calculate_rsi(self, prices: pd.Series, period: int = 14) -> np.ndarray:
        """Calculate Relative Strength Index"""
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        rs = gain / loss
        return 100 - (100 / (1 + rs))

    def calculate_macd(self, prices: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9) -> Tuple[np.ndarray, np.ndarray]:
        """Calculate MACD and Signal line"""
        exp1 = prices.ewm(span=fast, adjust=False).mean()
        exp2 = prices.ewm(span=slow, adjust=False).mean()
        macd = exp1 - exp2
        signal_line = macd.ewm(span=signal, adjust=False).mean()
        return macd.values, signal_line.values

    def calculate_bollinger_bands(self, prices: pd.Series, period: int = 20, std: int = 2) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Calculate Bollinger Bands"""
        middle_band = prices.rolling(window=period).mean()
        std_dev = prices.rolling(window=period).std()
        upper_band = middle_band + (std_dev * std)
        lower_band = middle_band - (std_dev * std)
        return upper_band.values, middle_band.values, lower_band.values

class PredictionTask:
    def __init__(self, ticker):
        self.ticker = ticker
        self.is_cancelled = False
        self.progress = 0
        self.logger = logging.getLogger(__name__)
        
    def start(self):
        def run_prediction():
            try:
                # Initialize predictor if needed
                predictor = TimeSeriesPredictor()
                
                # Update progress for initialization
                socketio.emit('prediction_progress', {
                    "step": "initialization",
                    "progress": 10
                }, room=self.ticker)
                
                if self.is_cancelled:
                    raise Exception("Prediction cancelled")
                
                # Load and preprocess data
                socketio.emit('prediction_progress', {
                    "step": "data_loading",
                    "progress": 30
                }, room=self.ticker)
                
                data = yf.download(self.ticker, start="2010-01-01", progress=False)
                if data.empty:
                    raise Exception(f"No data available for ticker {self.ticker}")
                
                if self.is_cancelled:
                    raise Exception("Prediction cancelled")
                
                # Make prediction
                socketio.emit('prediction_progress', {
                    "step": "prediction",
                    "progress": 60
                }, room=self.ticker)
                
                prediction = predictor.predict(data)
                
                if self.is_cancelled:
                    raise Exception("Prediction cancelled")
                
                # Format results
                socketio.emit('prediction_progress', {
                    "step": "formatting",
                    "progress": 90
                }, room=self.ticker)
                
                result = {
                    "ticker": self.ticker,
                    "prediction": prediction.tolist() if isinstance(prediction, np.ndarray) else prediction,
                    "timestamp": datetime.now(UTC).isoformat()
                }
                
                # Send final results
                socketio.emit('prediction_complete', result, room=self.ticker)
                
            except Exception as e:
                self.logger.error(f"Prediction error for {self.ticker}: {str(e)}")
                socketio.emit('prediction_error', 
                            {"error": str(e)}, 
                            room=self.ticker)
            finally:
                with prediction_lock:
                    if self.ticker in active_predictions:
                        del active_predictions[self.ticker]
        
        thread = threading.Thread(target=run_prediction)
        thread.daemon = True
        thread.start()

# ---------------------------- Auth Routes -----------------------------
@app.route("/api/auth/signup", methods=["POST"])
@cross_origin(supports_credentials=True)
def signup():
    try:
        data = request.get_json()
        if not data or 'email' not in data or 'password' not in data:
            return jsonify({"error": "Email and password are required"}), 400
            
        email = data['email']
        password = data['password']

        if email in users_db:
            return jsonify({
                "error": "Email already registered",
                "redirect": "login"
            }), 409
            
        users_db[email] = {
            "password": generate_password_hash(password),
            "is_subscribed": False
        }
        
        token = jwt.encode(
            {
                "email": email,
                "is_subscribed": False,
                "is_developer": False,
                "exp": datetime.now(UTC) + relativedelta(days=30)
            },
            app.secret_key,
            algorithm="HS256"
        )

        return jsonify({"token": token, "message": "Signup successful"}), 201
        
    except Exception as e:
        logger.error(f"Signup error: {str(e)}")
        return jsonify({"error": "An error occurred during signup"}), 500

@app.route("/api/auth/login", methods=["POST", "OPTIONS"])
@cross_origin(supports_credentials=True)
def login():
    try:
        if request.method == "OPTIONS":
            response = make_response()
            response.headers.update({
                'Access-Control-Allow-Origin': request.headers.get('Origin', 'http://localhost:5173'),
                'Access-Control-Allow-Methods': 'POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With',
                'Access-Control-Allow-Credentials': 'true',
                'Access-Control-Max-Age': '3600'
            })
            return response

        data = request.get_json()
        logger.info("Login attempt received")
        logger.debug(f"Login data: {data}")  # Add debug logging
        
        if not data:
            logger.warning("No data received in login request")
            return jsonify({"error": "No data provided"}), 400
            
        if 'email' not in data or 'password' not in data:
            logger.warning("Missing email or password in login request")
            return jsonify({"error": "Email and password are required"}), 400
            
        email = data['email']
        password = data['password']

        # Add developer user if it doesn't exist
        if "developer@vecaid.ai" not in users_db:
            users_db["developer@vecaid.ai"] = {
                "password": generate_password_hash("devpass"),
                "is_subscribed": True,
                "stripe_customer_id": None,
                "stripe_subscription_id": None
            }

        if email not in users_db:
            logger.warning(f"Login attempt with non-existent email: {email}")
            return jsonify({"error": "Invalid email or password"}), 401

        user = users_db[email]
        if not check_password_hash(user["password"], password):
            logger.warning(f"Invalid password attempt for email: {email}")
            return jsonify({"error": "Invalid email or password"}), 401

        # Generate token
        token = jwt.encode(
            {
                "email": email,
                "is_subscribed": user.get("is_subscribed", False),
                "is_developer": email == "developer@vecaid.ai",
                "exp": datetime.now(UTC) + relativedelta(days=30)
            },
            app.secret_key,
            algorithm="HS256"
        )
        
        # Create response
        response = make_response(jsonify({
            "token": token,
            "message": "Login successful",
            "user": {
                "email": email,
                "isSubscribed": user.get("is_subscribed", False),
                "isDeveloper": email == "developer@vecaid.ai"
            }
        }))
        
        # Set cookie
        response.set_cookie(
            'authToken',
            token,
            httponly=True,
            secure=False,  # Set to True in production
            samesite='Lax',
            domain='localhost',
            path='/',
            max_age=30 * 24 * 60 * 60  # 30 days
        )
        
        logger.info(f"Login successful for user: {email}")
        return response
        
    except Exception as e:
        logger.error(f"Login error: {str(e)}")
        return jsonify({"error": "An error occurred during login"}), 500

@app.route("/api/auth/developer", methods=["POST", "OPTIONS"])
@cross_origin(supports_credentials=True)
def developer_auth():
    try:
        if request.method == "OPTIONS":
            return make_response()

        data = request.get_json()
        if not data or 'key' not in data:
            return jsonify({"error": "Developer key is required"}), 400
        
        submitted_key = data['key']
        if submitted_key != DEVELOPER_KEY:
            return jsonify({"error": "Invalid developer key"}), 401
            
        # Generate a special developer token with direct access privileges
        token = jwt.encode(
            {
                "email": "developer@vecaid.ai",
                "is_subscribed": True,
                "is_developer": True,
                "direct_access": True,  # Special flag for direct prediction access
                "exp": datetime.now(UTC) + relativedelta(days=30)
            },
            app.secret_key,
            algorithm="HS256"
        )
        
        response = make_response(jsonify({
            "token": token,
            "message": "Developer authentication successful",
            "user": {
                "email": "developer@vecaid.ai",
                "isSubscribed": True,
                "isDeveloper": True,
                "directAccess": True
            },
            "redirect": "/prediction"  # Tell frontend to redirect directly to prediction page
        }))
        
        # Set cookie with the token
        response.set_cookie(
            'authToken',
            token,
            httponly=True,
            secure=False,  # Set to True in production
            samesite='Lax',
            domain='localhost',
            path='/',
            max_age=30 * 24 * 60 * 60  # 30 days
        )
        
        return response
        
    except Exception as e:
        logger.error(f"Developer auth error: {str(e)}")
        return jsonify({"error": "An error occurred during authentication"}), 500

@app.route("/api/auth/check", methods=["GET"])
@cross_origin(supports_credentials=True)
def check_auth():
    try:
        token = request.headers.get('Authorization', '').replace('Bearer ', '')
        if not token:
            return jsonify({"error": "No token provided"}), 401

        try:
            payload = jwt.decode(token, app.secret_key, algorithms=["HS256"])
            return jsonify({
                "user": {
                    "email": payload["email"],
                    "isSubscribed": payload["is_subscribed"],
                    "isDeveloper": payload["is_developer"],
                    "directAccess": payload.get("direct_access", False)
                }
            }), 200
        except jwt.ExpiredSignatureError:
            return jsonify({"error": "Token has expired"}), 401
        except jwt.InvalidTokenError:
            return jsonify({"error": "Invalid token"}), 401

    except Exception as e:
        logger.error(f"Auth check error: {str(e)}")
        return jsonify({"error": "An error occurred while checking authentication"}), 500

@app.route("/api/auth/logout", methods=["POST"])
@cross_origin(supports_credentials=True)
def logout():
    return jsonify({"message": "Logged out successfully"}), 200

# ---------------------------- Subscription Routes -----------------------------
@app.route("/api/subscription/check", methods=["GET"])
@cross_origin(supports_credentials=True)
def check_subscription():
    try:
        token = request.headers.get('Authorization', '').replace('Bearer ', '')
        if not token:
            return jsonify({"isSubscribed": False})
            
        # Verify token
        try:
            payload = jwt.decode(token, app.secret_key, algorithms=["HS256"])
            email = payload["email"]
            
            # Check if user is developer (they get automatic subscription)
            if payload.get("is_developer"):
                return jsonify({"isSubscribed": True})
                
            # Check if user exists and is subscribed
            if email in users_db:
                return jsonify({"isSubscribed": users_db[email]["is_subscribed"]})
            
            return jsonify({"isSubscribed": False})

        except jwt.InvalidTokenError:
            return jsonify({"isSubscribed": False})
            
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/subscription/create-checkout', methods=['POST'])
@cross_origin(supports_credentials=True)
def create_checkout_session():
    try:
        # Get user email from token
        token = request.headers.get('Authorization', '').replace('Bearer ', '')
        if not token:
            return jsonify({"error": "Authentication required"}), 401
            
        try:
            payload = jwt.decode(token, app.secret_key, algorithms=["HS256"])
            email = payload["email"]
        except jwt.InvalidTokenError:
            return jsonify({"error": "Invalid token"}), 401

        # Create Stripe checkout session with dynamic price
        session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=[{
                'price_data': {
                    'currency': 'usd',
                    'product_data': {
                        'name': 'VECAID Premium Subscription',
                        'description': 'Monthly access to all VECAID premium features'
                    },
                    'unit_amount': 999,  # $9.99 in cents
                    'recurring': {
                        'interval': 'month'
                    }
                },
                'quantity': 1,
            }],
            mode='subscription',
            success_url=STRIPE_CONFIG['success_url'],
            cancel_url=STRIPE_CONFIG['cancel_url'],
            customer_email=email,
        )

        return jsonify({'url': session.url, 'sessionId': session.id})
    except Exception as e:
        logger.error(f"Error creating checkout session: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/subscription/success', methods=['GET'])
@cross_origin(supports_credentials=True)
def subscription_success():
    try:
        # Get user email from token
        token = request.headers.get('Authorization', '').replace('Bearer ', '')
        if not token:
            return jsonify({"error": "Authentication required"}), 401
            
        try:
            payload = jwt.decode(token, app.secret_key, algorithms=["HS256"])
            email = payload["email"]
        except jwt.InvalidTokenError:
            return jsonify({"error": "Invalid token"}), 401

        # Update user subscription status
        if email in users_db:
            users_db[email]["is_subscribed"] = True
            
        return jsonify({
            "success": True,
            "message": "Subscription activated successfully"
        })
        
    except Exception as e:
        logger.error(f"Error in subscription success: {str(e)}")
        return jsonify({"error": str(e)}), 500
    
@app.route("/api/info", methods=["POST"])
@cross_origin(supports_credentials=True)
def start_prediction():
    data = request.get_json()
    ticker = data.get("ticker")
    
    if not ticker:
        return jsonify({"error": "Ticker symbol is required"}), 400

    with prediction_lock:
        if ticker in active_predictions:
            return jsonify({
                "error": "Prediction already in progress",
                "websocket_channel": ticker
            }), 409

        try:
            task = PredictionTask(ticker)
            active_predictions[ticker] = task
            task.start()
            
            return jsonify({
                "message": "Prediction started",
                "websocket_channel": ticker
            }), 202
            
        except Exception as e:
            logger.error(f"Error starting prediction for {ticker}: {str(e)}")
            return jsonify({"error": str(e)}), 500

@app.route("/api/info/cancel/<ticker>", methods=["POST"])
@cross_origin(supports_credentials=True)
def cancel_prediction(ticker):
    ticker = ticker.upper()
    with prediction_lock:
        if ticker in active_predictions:
            task = active_predictions[ticker]
            task.cancel()
            del active_predictions[ticker]
            logger.info(f"Prediction cancelled for {ticker}")
            return jsonify({"message": f"Prediction cancelled for {ticker}"}), 200
    return jsonify({"message": f"No active prediction found for {ticker}"}), 404


@app.route("/api/info/status/<ticker>", methods=["GET"])
@cross_origin(supports_credentials=True)
def prediction_status(ticker):
    ticker = ticker.upper()
    with prediction_lock:
        if ticker in active_predictions:
            task = active_predictions[ticker]
            try:
                result_type, result = task.result_queue.get_nowait()
                if result_type == "progress":
                    return jsonify(result)
                elif result_type == "success":
                    return jsonify(result)
                elif result_type == "error":
                    return jsonify({"error": result}), 500
            except queue.Empty:
                return jsonify({"status": "running"})
    return jsonify({"status": "not_found"}), 404

# Initialize Flask-SocketIO
socketio = SocketIO(app, cors_allowed_origins="*")
active_socket_clients = {}

@socketio.on('connect')
def handle_connect():
    logger.info(f"Client connected: {request.sid}")

@socketio.on('disconnect')
def handle_disconnect():
    logger.info(f"Client disconnected: {request.sid}")
    # Remove client from active subscriptions
    if request.sid in active_socket_clients:
        ticker = active_socket_clients[request.sid]
        leave_room(ticker)
        del active_socket_clients[request.sid]

@socketio.on('subscribe')
def handle_subscribe(data):
    ticker = data.get('ticker')
    if ticker:
        join_room(ticker)
        active_socket_clients[request.sid] = ticker
        logger.info(f"Client {request.sid} subscribed to {ticker} updates")

@socketio.on('prediction_request')
def handle_prediction_request(data):
    try:
        ticker = data.get('ticker')
        if ticker:
            # Emit initial status
            emit('prediction_status', {
                'ticker': ticker,
                'status': 'started',
                'message': f'Starting prediction for {ticker}'
            })
            
            # Start prediction process in PredictionTask
            with prediction_lock:
                if ticker not in active_predictions:
                    task = PredictionTask(ticker)
                    active_predictions[ticker] = task
                    task.start()
                else:
                    emit('prediction_error', {
                        'ticker': ticker,
                        'error': 'Prediction already in progress'
                    })
                    
    except Exception as e:
        logger.error(f"Error in prediction request: {str(e)}")
        emit('prediction_error', {'error': str(e)})

if __name__ == "__main__":
    try:
        logger.info("Initializing VECAID Backend...")
        
        # Start Flask-SocketIO server
        logger.info("Starting Flask-SocketIO server on port 8080...")
        socketio.run(app, host='0.0.0.0', port=8080, debug=True)
        
    except Exception as e:
        logger.error(f"Critical error in main: {str(e)}")
        raise
