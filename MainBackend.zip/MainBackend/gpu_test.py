import torch
import sys
import platform

def check_gpu():
    print("\n=== System Information ===")
    print(f"Python version: {sys.version}")
    print(f"PyTorch version: {torch.__version__}")
    print(f"Operating System: {platform.system()} {platform.release()}")

    print("\n=== CUDA Information ===")
    print(f"CUDA available: {torch.cuda.is_available()}")
    
    if torch.cuda.is_available():
        print(f"CUDA version: {torch.version.cuda}")
        print(f"cuDNN version: {torch.backends.cudnn.version()}")
        print(f"Number of GPUs: {torch.cuda.device_count()}")
        
        for i in range(torch.cuda.device_count()):
            print(f"\nGPU {i}: {torch.cuda.get_device_name(i)}")
            print(f"GPU {i} Memory: {torch.cuda.get_device_properties(i).total_memory / 1024**3:.2f} GB")
            
        # Test CUDA memory allocation
        print("\n=== Testing CUDA Memory Allocation ===")
        try:
            test_tensor = torch.zeros(1000, 1000).cuda()
            print("✅ Successfully allocated memory on GPU")
            del test_tensor
            torch.cuda.empty_cache()
        except Exception as e:
            print(f"❌ Error allocating memory on GPU: {str(e)}")
    else:
        print("❌ No CUDA-capable GPU detected")

if __name__ == "__main__":
    check_gpu() 